﻿# NX 1872
# Journal created by Admin on Fri Jun 14 16:37:04 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "C:\\Users\\Admin\\Desktop\\robot\\model1.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    # User Function call - UF_PART_ask_part_name
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane2
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId8, "Create Sketch Dialog")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.96717310821995506
    rotMatrix1.Xy = -0.037902318152265115
    rotMatrix1.Xz = -0.25127593003476495
    rotMatrix1.Yx = -0.074545173927966904
    rotMatrix1.Yy = 0.90299481798975578
    rotMatrix1.Yz = -0.42313517429740721
    rotMatrix1.Zx = 0.24293866670458361
    rotMatrix1.Zy = 0.42797636963076907
    rotMatrix1.Zz = 0.87052686992273165
    translation1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.89692984317447444)
    
    scaleAboutPoint1 = NXOpen.Point3d(-199.11674403419221, -102.06576805308221, 0.0)
    viewCenter1 = NXOpen.Point3d(199.11674403419221, 102.06576805308221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(-159.29339522735378, -81.652614442465804, 0.0)
    viewCenter2 = NXOpen.Point3d(159.29339522735376, 81.652614442465762, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-127.43471618188302, -65.322091553972626, 0.0)
    viewCenter3 = NXOpen.Point3d(127.43471618188302, 65.322091553972598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(18.124048523645584, 10.723395376490293, 0.0)
    viewCenter4 = NXOpen.Point3d(-18.124048523645559, -10.723395376490306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(113.65288761702749, 37.758434424261623, 0.0)
    viewCenter5 = NXOpen.Point3d(-113.65288761702749, -37.758434424261651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(142.0661095212844, 47.198043030327035, 0.0)
    viewCenter6 = NXOpen.Point3d(-142.0661095212844, -47.19804303032705, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(180.53251459100096, 62.242419246243799, 0.0)
    viewCenter7 = NXOpen.Point3d(-180.53251459100096, -62.242419246243799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(144.897992103104, 49.793935396995046, 0.0)
    viewCenter8 = NXOpen.Point3d(-144.897992103104, -49.793935396995046, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(115.9183936824832, 39.83514831759603, 0.0)
    viewCenter9 = NXOpen.Point3d(-115.9183936824832, -39.83514831759603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem1
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane3.SetGeometry(geom1)
    
    plane3.SetFlip(True)
    
    plane3.SetExpression(None)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane4.SynchronizeToPlane(plane3)
    
    plane4.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane4.SetGeometry(geom2)
    
    plane4.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane4.Evaluate()
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.98823059981261174
    rotMatrix2.Xy = -0.019213387929888876
    rotMatrix2.Xz = -0.15176009791200679
    rotMatrix2.Yx = 0.01539713983851834
    rotMatrix2.Yy = 0.9995359865263439
    rotMatrix2.Yz = -0.026281927699531638
    rotMatrix2.Zx = 0.15219464405424882
    rotMatrix2.Zy = 0.02363593372528211
    rotMatrix2.Zz = 0.98806787871994806
    translation2 = NXOpen.Point3d(77.359952428857497, 43.353762425506865, 0.0)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 1.7518160999501455)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId9, None)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject3 = sketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject3
    feature2 = sketch2.Feature
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId12)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId10, None)
    
    theSession.SetUndoMarkName(markId8, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane2.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression5)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Profile...
    # ----------------------------------------------
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId13, "Curve")
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId15, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(14.000000000000002, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(14.000000000000002, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(14.000000000000002, 0.0, 17.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(14.000000000000002, 0.0, 17.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 17.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 17.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(2:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(7.0000000000000009, 0.0, -5.1375255657578043)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression7 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(19.137525565757805, 0.0, 8.5)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression8 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension1 = dimension2
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension1)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId16, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits3 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits7 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits11 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("20")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject4 = sketchLinearDimensionBuilder1.Commit()
    
    point1_1 = NXOpen.Point3d(16.47058823529412, 0.0, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(16.47058823529412, 0.0, 20.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("20")
    
    theSession.SetUndoMarkName(markId18, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId16, "Linear Dimension")
    
    expression9 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId18, None)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension2 = dimension1
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension2)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId21, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits19 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits21 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits25 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId22, None)
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point3 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin1.PointOnGeometry = point3
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point4 = NXOpen.Point3d(8.0047880979434503, 0.0, -4.0779109178202573)
    sketchLinearDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point4)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder2.Style.DimensionStyle.TextCentered = True
    
    dimensionlinearunits37 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits43 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId23, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId23, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId21, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("20")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject6 = sketchLinearDimensionBuilder2.Commit()
    
    point1_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(20.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("20")
    
    theSession.SetUndoMarkName(markId24, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId21, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject7 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.SetUndoMarkName(markId21, "Linear Dimension")
    
    expression10 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.SetUndoMarkVisibility(markId21, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.DeleteUndoMark(markId23, None)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId27, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line3
    curves1[1] = line1
    curves1[2] = line4
    curves1[3] = line2
    seedPoint1 = NXOpen.Point3d(6.6666666666666661, 0.0, 13.333333333333334)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId28, None)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId30, None)
    
    direction2 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId29, None)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.99760364738870488
    rotMatrix3.Xy = 0.049483832346842546
    rotMatrix3.Xz = 0.048356106677671956
    rotMatrix3.Yx = 0.025367265061616202
    rotMatrix3.Yy = -0.91183744859948945
    rotMatrix3.Yz = 0.40976696937999602
    rotMatrix3.Zx = 0.064369748951246641
    rotMatrix3.Zy = -0.40755836105745941
    rotMatrix3.Zz = -0.91090763403986819
    translation3 = NXOpen.Point3d(0.24634200764503511, -6.7993809620974641, 14.142304144428106)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 1.7518160999501451)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("50")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("7")
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature3 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.SetUndoMarkName(markId27, "Extrude")
    
    expression13 = extrudeBuilder1.Limits.StartExtend.Value
    expression14 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression11)
    
    workPart.Expressions.Delete(expression12)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.95988697778354803
    rotMatrix4.Xy = -0.00059727204743635978
    rotMatrix4.Xz = 0.28038657804479333
    rotMatrix4.Yx = -0.11917452719022747
    rotMatrix4.Yy = 0.90430553574160277
    rotMatrix4.Yz = 0.40991332022280064
    rotMatrix4.Zx = -0.25379996444159286
    rotMatrix4.Zy = -0.42688539597085751
    rotMatrix4.Zz = 0.86795992808208144
    translation4 = NXOpen.Point3d(-1.8720798753545882, 1.0010738971867505, -0.53231896505988807)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 1.7518160999501451)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.98206464876857014
    rotMatrix5.Xy = 0.022337877867306781
    rotMatrix5.Xz = 0.18721657205347408
    rotMatrix5.Yx = 0.10136789208508835
    rotMatrix5.Yy = 0.77468599092140245
    rotMatrix5.Yz = -0.62416837946531301
    rotMatrix5.Zx = -0.15897665266728603
    rotMatrix5.Zy = 0.63195144962450578
    rotMatrix5.Zz = 0.75852738198709402
    translation5 = NXOpen.Point3d(-1.0818835005900134, 8.6827982944440301, 3.3197023377306918)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 1.7518160999501451)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    extrude1 = feature3
    editWithRollbackManager1 = workPart.Features.StartEditWithRollbackManager(extrude1, markId34)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(extrude1)
    
    section1.PrepareMappingData()
    
    refs1 = section1.EvaluateAndAskOutputEntities()
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.SetUndoMarkName(markId35, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    direction3 = extrudeBuilder2.Direction
    
    success1 = direction3.ReverseDirection()
    
    extrudeBuilder2.Direction = direction3
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("19")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("7")
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId37, None)
    
    theSession.SetUndoMarkName(markId35, "Extrude")
    
    section1.CleanMappingData()
    
    expression17 = extrudeBuilder2.Limits.StartExtend.Value
    expression18 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression15)
    
    workPart.Expressions.Delete(expression16)
    
    theSession.DeleteUndoMark(markId35, None)
    
    editWithRollbackManager1.UpdateFeature(False)
    
    editWithRollbackManager1.Stop()
    
    editWithRollbackManager1.Destroy()
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.95765971449812659
    rotMatrix6.Xy = -0.069551895430612312
    rotMatrix6.Xz = -0.27937502585124163
    rotMatrix6.Yx = 0.038830732438822096
    rotMatrix6.Yy = 0.99271748770107149
    rotMatrix6.Yz = -0.11403580065375231
    rotMatrix6.Zx = 0.28527187987188002
    rotMatrix6.Zy = 0.098359155417718627
    rotMatrix6.Zz = 0.95338629689118193
    translation6 = NXOpen.Point3d(4.1496960277042962, 3.4437338640622435, -1.2037991069780931)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.7518160999501451)
    
    scaleAboutPoint10 = NXOpen.Point3d(25.826769146194959, 7.2496194094582345, 0.0)
    viewCenter10 = NXOpen.Point3d(-25.826769146194959, -7.249619409458222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(20.661415316955949, 5.7996955275665885, 0.0)
    viewCenter11 = NXOpen.Point3d(-20.661415316955992, -5.7996955275665885, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(16.529132253564761, 4.6397564220532708, 0.0)
    viewCenter12 = NXOpen.Point3d(-16.529132253564793, -4.6397564220532708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane5
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId38, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature4
    edge1 = extrude2.FindObject("EDGE * 120 * 170 {(0,0,20)(10,0,20)(20,0,20) EXTRUDE(3)}")
    point5 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction4 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude2.FindObject("FACE 170 {(10,3.5,20) EXTRUDE(3)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction4, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem2
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane6.SetGeometry(geom4)
    
    plane6.SetFlip(False)
    
    plane6.SetExpression(None)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane7.SynchronizeToPlane(plane6)
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point6 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane7.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane7.SetGeometry(geom5)
    
    plane7.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane7.Evaluate()
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject8 = sketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject8
    feature5 = sketch3.Feature
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId41)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId38, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression20)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point6)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression19)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane5.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression22)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression21)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    scaleAboutPoint13 = NXOpen.Point3d(-6.4183297171737097, -3.7118051376426169, 0.0)
    viewCenter13 = NXOpen.Point3d(6.4183297171736831, 3.7118051376426102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-5.3821174495818154, -2.7838538532319679, 0.0)
    viewCenter14 = NXOpen.Point3d(5.3821174495817736, 2.7838538532319625, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-10.492035855736493, 2.2270830825855663, 0.0)
    viewCenter15 = NXOpen.Point3d(10.492035855736443, -2.2270830825855747, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-8.3936286845891956, 1.7816664660684531, 0.0)
    viewCenter16 = NXOpen.Point3d(8.3936286845891548, -1.7816664660684598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId43, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(3.399999999999995, 1.8, 20.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 0.053008037476867977, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(3.399999999999995, 2.159139067176004, 20.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression23 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint17 = NXOpen.Point3d(-9.9139840689676113, 2.2805330765676213, 0.0)
    viewCenter17 = NXOpen.Point3d(9.9139840689675669, -2.280533076567627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-7.9311872551740921, 1.8244264612540948, 0.0)
    viewCenter18 = NXOpen.Point3d(7.9311872551740485, -1.8244264612541035, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-6.3449498041392784, 1.459541169003276, 0.0)
    viewCenter19 = NXOpen.Point3d(6.3449498041392349, -1.4595411690032831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-5.075959843311427, 1.1676329352026193, 0.0)
    viewCenter20 = NXOpen.Point3d(5.0759598433113835, -1.1676329352026276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-4.0607678746491462, 0.96005374672215271, 0.0)
    viewCenter21 = NXOpen.Point3d(4.0607678746491018, -0.96005374672216159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-3.2486142997193199, 0.7680429973777203, 0.0)
    viewCenter22 = NXOpen.Point3d(3.2486142997192764, -0.76804299737773096, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-3.0140498167363927, 0.45667421465702052, 0.0)
    viewCenter23 = NXOpen.Point3d(3.0140498167363501, -0.45667421465703112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-3.7675622709204855, 0.57084276832127745, 0.0)
    viewCenter24 = NXOpen.Point3d(3.7675622709204424, -0.57084276832128811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-4.7094528386506012, 0.71355346040159773, 0.0)
    viewCenter25 = NXOpen.Point3d(4.7094528386505567, -0.71355346040160994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId45, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension1)
    
    perpendicularDimension2 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension2)
    
    diameterDimension1 = dimension3
    theSession.UpdateManager.LogForUpdate(diameterDimension1)
    
    center2 = NXOpen.Point3d(3.399999999999995, 1.8, 20.0)
    arc1.SetParameters(0.87382298251735602, center2, 0.0, ( 360.0 * math.pi/180.0 ))
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("ENTITY 243 2 1")
    sketchHelpedDimensionalConstraint3.Refresh()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("ENTITY 243 1 1")
    sketchHelpedDimensionalConstraint4.Refresh()
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId45)
    
    geoms3 = [NXOpen.SmartObject.Null] * 1 
    geoms3[0] = arc1
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 1 
    geoms4[0] = arc1
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms4)
    
    geoms5 = [NXOpen.SmartObject.Null] * 1 
    geoms5[0] = arc1
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms5)
    
    scaleAboutPoint26 = NXOpen.Point3d(-3.5515501779080028, -0.25947398560058882, 0.0)
    viewCenter26 = NXOpen.Point3d(3.5515501779079557, 0.25947398560057638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-4.4394377223849961, -0.32434248200073257, 0.0)
    viewCenter27 = NXOpen.Point3d(4.4394377223849455, 0.32434248200072219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-5.9040467426695384, 1.9257834868793218, 0.0)
    viewCenter28 = NXOpen.Point3d(5.904046742669486, -1.9257834868793327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-7.4117324988447937, 2.502251570122803, 0.0)
    viewCenter29 = NXOpen.Point3d(7.4117324988447448, -2.5022515701228141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-10.531628443871334, 7.6809620981617766, 0.0)
    viewCenter30 = NXOpen.Point3d(10.531628443871286, -7.6809620981617934, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-13.21402629000773, 9.799165563376496, 0.0)
    viewCenter31 = NXOpen.Point3d(13.214026290007675, -9.7991655633765085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Object Origin")
    
    diameterDimension1.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromRight
    
    diameterDimension1.IsOriginCentered = False
    
    diameterDimension1.DiameterDimensionLineAngle = 0.0
    
    origin8 = NXOpen.Point3d(-9.3820648850151649, 3.9035984128189307, 20.0)
    diameterDimension1.AnnotationOrigin = origin8
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId46)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(diameterDimension1)
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId47, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits49 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits51 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits55 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId48, None)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("1")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("1")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject9 = sketchRadialDimensionBuilder1.Commit()
    
    point1_5 = NXOpen.Point3d(10.501508696748513, 1.0299568883043777, 20.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    theSession.SetUndoMarkName(markId49, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId49, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    scaleAboutPoint32 = NXOpen.Point3d(-13.486225333434858, 11.939639859417074, 0.0)
    viewCenter32 = NXOpen.Point3d(13.486225333434806, -11.939639859417085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-10.788980266747892, 9.5517118875336564, 0.0)
    viewCenter33 = NXOpen.Point3d(10.788980266747838, -9.5517118875336688, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-8.6311842133983276, 7.6413695100269221, 0.0)
    viewCenter34 = NXOpen.Point3d(8.6311842133982672, -7.641369510026939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-3.5158218263751162, 1.3303109613311046, 0.0)
    viewCenter35 = NXOpen.Point3d(3.5158218263750514, -1.3303109613311181, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-1.038909512658619, -1.7230694356288749, 0.0)
    viewCenter36 = NXOpen.Point3d(1.0389095126585497, 1.7230694356288641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-1.5406267895034942, -1.3987269536281457, 0.0)
    viewCenter37 = NXOpen.Point3d(1.5406267895034287, 1.3987269536281353, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-1.2325014316028013, -1.1189815629025184, 0.0)
    viewCenter38 = NXOpen.Point3d(1.2325014316027352, 1.1189815629025073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject10 = sketchRadialDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId51, None)
    
    theSession.SetUndoMarkName(markId47, "Radial Dimension")
    
    expression24 = sketchRadialDimensionBuilder1.Driving.ExpressionValue
    sketchRadialDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId50, None)
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId49, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension1)
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId52, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits67 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits69 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId53, None)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point7
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point8 = NXOpen.Point3d(11.780442702663899, 0.17976029579037217, 20.0)
    sketchLinearDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits85 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits91 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId54, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("0.8")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject11 = sketchLinearDimensionBuilder3.Commit()
    
    taggedObject1 = sketchLinearDimensionBuilder3.FirstAssociativity.Value
    
    line5 = taggedObject1
    point1_6 = NXOpen.Point3d(34.287499999999994, 0.0, 20.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, NXOpen.View.Null, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(10.501508696748513, 0.80000000000000071, 20.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("0.8")
    
    theSession.SetUndoMarkName(markId55, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId55, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject12 = sketchLinearDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.SetUndoMarkName(markId52, "Linear Dimension")
    
    expression25 = sketchLinearDimensionBuilder3.Driving.ExpressionValue
    sketchLinearDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.DeleteUndoMark(markId54, None)
    
    scaleAboutPoint39 = NXOpen.Point3d(-3.8012938890485661, -0.86923785176195678, 0.0)
    viewCenter39 = NXOpen.Point3d(3.8012938890485062, 0.86923785176194579, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-3.0410351112388589, -0.69539028140956649, 0.0)
    viewCenter40 = NXOpen.Point3d(3.0410351112388017, 0.69539028140955594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-2.4328280889910916, -0.55631222512765399, 0.0)
    viewCenter41 = NXOpen.Point3d(2.4328280889910379, 0.55631222512764333, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-2.0525430156948774, -0.41183710994525052, 0.0)
    viewCenter42 = NXOpen.Point3d(2.0525430156948232, 0.41183710994523975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-2.5822851046970272, -0.51479638743156164, 0.0)
    viewCenter43 = NXOpen.Point3d(2.5822851046969735, 0.51479638743155109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-3.2589932591433466, -0.63311652486542669, 0.0)
    viewCenter44 = NXOpen.Point3d(3.2589932591432929, 0.63311652486541603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-7.3041926946564324, 3.3861355120875998, 0.0)
    viewCenter45 = NXOpen.Point3d(7.30419269465638, -3.3861355120876109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-9.1626751165206048, 4.2975378865096481, 0.0)
    viewCenter46 = NXOpen.Point3d(9.1626751165205533, -4.2975378865096587, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(-11.372258275150569, 4.6826945838855121, 0.0)
    viewCenter47 = NXOpen.Point3d(11.372258275150514, -4.6826945838855236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    origin9 = NXOpen.Point3d(12.239831663895703, -2.4277424368821783, 19.999999999999996)
    workPart.ModelingViews.WorkView.SetOrigin(origin9)
    
    origin10 = NXOpen.Point3d(12.239831663895703, -2.4277424368821783, 19.999999999999996)
    workPart.ModelingViews.WorkView.SetOrigin(origin10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId58, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder1.Destroy()
    
    theSession.UndoToMark(markId58, None)
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    theSession.SetUndoMarkName(markId59, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    point9 = NXOpen.Point3d(0.0, 1.3731460240638613, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(datumAxis2, workPart.ModelingViews.WorkView, point9)
    
    point1_8 = NXOpen.Point3d(10.501508696748513, 0.80000000000000071, 20.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point10 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point10
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point11 = NXOpen.Point3d(5.2461968957549958, -2.4024031804758681, 20.0)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point11)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = True
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject13 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId59, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId59, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId61, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression26 = workPart.Expressions.FindObject("p12")
    expression26.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId62, None)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId61, "Edit Driving Value")
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId63, None)
    
    theSession.DeleteUndoMark(markId63, None)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    scaleAboutPoint48 = NXOpen.Point3d(3.6235136661018599, 3.2687640764135875, 0.0)
    viewCenter48 = NXOpen.Point3d(-3.6235136661019118, -3.2687640764135986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId65, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(17.262072283625727, 0.80000000000000071, 20.0)
    arc2 = workPart.Curves.CreateArc(center3, nXMatrix2, 0.40542810250090966, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc2
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(17.262072283625727, 1.029849002992643, 20.0)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    expression27 = sketchDimensionalConstraint4.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    theSession.SetUndoMarkName(markId66, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Destroy()
    
    theSession.UndoToMark(markId66, None)
    
    theSession.DeleteUndoMark(markId66, None)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Object Origin")
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    perpendicularDimension3.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromLeft
    
    perpendicularDimension3.IsOriginCentered = True
    
    origin11 = NXOpen.Point3d(18.59998502187873, -1.3482901139735022, 20.0)
    perpendicularDimension3.AnnotationOrigin = origin11
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId67)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension3)
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId68, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits183 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits185 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits189 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits197 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId69, None)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    nXObject14 = sketchLinearDimensionBuilder4.Commit()
    
    taggedObject2 = sketchLinearDimensionBuilder4.FirstAssociativity.Value
    
    line6 = taggedObject2
    point1_9 = NXOpen.Point3d(19.999999999999996, 14.2875, 20.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(16.999999999999996, 0.80000000000000071, 20.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("3")
    
    theSession.SetUndoMarkName(markId70, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    scaleAboutPoint49 = NXOpen.Point3d(5.2705653325118078, 0.95275604087713495, 0.0)
    viewCenter49 = NXOpen.Point3d(-5.2705653325118629, -0.95275604087714527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(4.26510363830955, 1.3460213003030179, 0.0)
    viewCenter50 = NXOpen.Point3d(-4.2651036383096068, -1.3460213003030288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(3.4120829106476358, 1.3752121236830848, 0.0)
    viewCenter51 = NXOpen.Point3d(-3.41208291064769, -1.3752121236830936, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(4.26510363830955, 1.7190151546038572, 0.0)
    viewCenter52 = NXOpen.Point3d(-4.2651036383096068, -1.7190151546038654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(5.3313795478869395, 2.1487689432548227, 0.0)
    viewCenter53 = NXOpen.Point3d(-5.3313795478869981, -2.1487689432548298, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(6.6642244348586832, 2.6859611790685305, 0.0)
    viewCenter54 = NXOpen.Point3d(-6.6642244348587436, -2.6859611790685367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(6.5565325951318849, 5.4796141978638664, 0.0)
    viewCenter55 = NXOpen.Point3d(-6.5565325951319418, -5.4796141978638717, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(8.1956657439148639, 7.4434065693526517, 0.0)
    viewCenter56 = NXOpen.Point3d(-8.195665743914919, -7.4434065693526623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(11.976757910793475, 14.451294669221905, 0.0)
    viewCenter57 = NXOpen.Point3d(-11.976757910793514, -14.451294669221912, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(14.970947388491846, 18.064118336527379, 0.0)
    viewCenter58 = NXOpen.Point3d(-14.970947388491886, -18.06411833652739, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(18.713684235614817, 22.580147920659229, 0.0)
    viewCenter59 = NXOpen.Point3d(-18.713684235614846, -22.580147920659236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject15 = sketchLinearDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId72, None)
    
    theSession.SetUndoMarkName(markId68, "Linear Dimension")
    
    expression28 = sketchLinearDimensionBuilder4.Driving.ExpressionValue
    sketchLinearDimensionBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId71, None)
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId70, None)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    diameterDimension2 = dimension4
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(diameterDimension2)
    
    sketchRadialDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId73, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits201 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits203 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits207 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits213 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId74, None)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point12 = workPart.Points.FindObject("ENTITY 2 8")
    assocOrigin4.PointOnGeometry = point12
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point13 = NXOpen.Point3d(17.662209331629761, 16.236962896747208, 20.0)
    sketchRadialDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point13)
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.DiameterDimensionDimLineAngle = 0.0
    
    sketchRadialDimensionBuilder2.Style.DimensionStyle.TextAngle = 82.590869974550145
    
    sketchRadialDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits219 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId75, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder2.Driving.ExpressionValue.SetFormula("1")
    
    sketchRadialDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject16 = sketchRadialDimensionBuilder2.Commit()
    
    point1_11 = NXOpen.Point3d(16.999999999999996, 0.80000000000000071, 20.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    sketchRadialDimensionBuilder2.Driving.ExpressionValue.SetFormula("1")
    
    theSession.SetUndoMarkName(markId76, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    scaleAboutPoint60 = NXOpen.Point3d(27.065245795310695, 19.042333648843613, 0.0)
    viewCenter60 = NXOpen.Point3d(-27.065245795310727, -19.04233364884362, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(17.708403677503281, 18.481696414512179, 0.0)
    viewCenter61 = NXOpen.Point3d(-17.708403677503309, -18.481696414512186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(14.166722942002625, 14.785357131609743, 0.0)
    viewCenter62 = NXOpen.Point3d(-14.166722942002647, -14.785357131609748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(11.333378353602091, 11.828285705287788, 0.0)
    viewCenter63 = NXOpen.Point3d(-11.333378353602107, -11.828285705287797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(8.8291471540725528, 9.6209989167696488, 0.0)
    viewCenter64 = NXOpen.Point3d(-8.8291471540725723, -9.6209989167696559, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(7.0633177232580362, 7.6967991334157189, 0.0)
    viewCenter65 = NXOpen.Point3d(-7.0633177232580575, -7.6967991334157269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(5.6506541786064295, 6.1574393067325737, 0.0)
    viewCenter66 = NXOpen.Point3d(-5.650654178606449, -6.1574393067325826, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(4.5205233428851361, 4.9259514453860582, 0.0)
    viewCenter67 = NXOpen.Point3d(-4.5205233428851566, -4.9259514453860644, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(3.0326022067067981, 3.2272076959072451, 0.0)
    viewCenter68 = NXOpen.Point3d(-3.0326022067068203, -3.2272076959072518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(3.7907527583835017, 4.0340096198840563, 0.0)
    viewCenter69 = NXOpen.Point3d(-3.7907527583835221, -4.0340096198840651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(4.738440947979381, 5.0425120248550703, 0.0)
    viewCenter70 = NXOpen.Point3d(-4.7384409479794005, -5.0425120248550792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(3.7907527583834972, 4.0340096198840536, 0.0)
    viewCenter71 = NXOpen.Point3d(-3.7907527583835181, -4.0340096198840643, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject17 = sketchRadialDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId78, None)
    
    theSession.SetUndoMarkName(markId73, "Radial Dimension")
    
    expression29 = sketchRadialDimensionBuilder2.Driving.ExpressionValue
    sketchRadialDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId76, None)
    
    theSession.DeleteUndoMark(markId75, None)
    
    scaleAboutPoint72 = NXOpen.Point3d(-3.7623727912084606, 3.0974707031069508, 0.0)
    viewCenter72 = NXOpen.Point3d(3.7623727912084384, -3.0974707031069615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-4.7029659890105746, 3.8718383788836892, 0.0)
    viewCenter73 = NXOpen.Point3d(4.7029659890105542, -3.8718383788837016, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-5.878707486263214, 4.8397979736046137, 0.0)
    viewCenter74 = NXOpen.Point3d(5.8787074862631865, -4.8397979736046244, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section2
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("7")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId79, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves2 = [NXOpen.ICurve.Null] * 2 
    curves2[0] = arc1
    curves2[1] = arc2
    seedPoint2 = NXOpen.Point3d(17.166666666666664, 0.80000000000000071, 20.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves2, seedPoint2, 0.01)
    
    curves3 = [NXOpen.ICurve.Null] * 2 
    curves3[0] = arc1
    curves3[1] = arc2
    seedPoint3 = NXOpen.Point3d(3.0, 0.63333333333333408, 20.0)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves3, seedPoint3, 0.01)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 2 
    rules2[0] = regionBoundaryRule2
    rules2[1] = regionBoundaryRule3
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId80, None)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId82, None)
    
    direction5 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction5
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(3)")
    targetBodies4[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId81, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("1")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.53665043097709009
    rotMatrix7.Xy = -0.2217008783675179
    rotMatrix7.Xz = -0.81415909714451662
    rotMatrix7.Yx = -0.3317855691033702
    rotMatrix7.Yy = 0.83170767089083031
    rotMatrix7.Yz = -0.44517489407659039
    rotMatrix7.Zx = 0.77583803146459362
    rotMatrix7.Zy = 0.50902953815316232
    rotMatrix7.Zz = 0.37277912793063234
    translation7 = NXOpen.Point3d(-0.39149689373149776, 15.719188141811085, -28.436100782667708)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 8.3533101079470971)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("0.8")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId83, None)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId84, None)
    
    theSession.SetUndoMarkName(markId79, "Extrude")
    
    expression33 = extrudeBuilder3.Limits.StartExtend.Value
    expression34 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression30)
    
    workPart.Expressions.Delete(expression31)
    
    workPart.Expressions.Delete(expression32)
    
    scaleAboutPoint75 = NXOpen.Point3d(-2.2805330765676368, 2.0588145830124307, 0.0)
    viewCenter75 = NXOpen.Point3d(2.2805330765676048, -2.0588145830124414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-1.8244264612541097, 1.672390922816251, 0.0)
    viewCenter76 = NXOpen.Point3d(1.8244264612540817, -1.6723909228162641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.57570989877582301
    rotMatrix8.Xy = -0.19135000522201134
    rotMatrix8.Xz = -0.79494860711436433
    rotMatrix8.Yx = 0.0054088957552687975
    rotMatrix8.Yy = 0.97310099634294855
    rotMatrix8.Yz = -0.23031542450098677
    rotMatrix8.Zx = 0.81763613930540047
    rotMatrix8.Zy = 0.12829507557929631
    rotMatrix8.Zz = 0.56125886833426808
    translation8 = NXOpen.Point3d(-0.59251459278858865, 5.5996701009078294, -31.415358688215498)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 13.052047043667338)
    
    scaleAboutPoint77 = NXOpen.Point3d(-1.2568271177528372, 2.1690403483798639, 0.0)
    viewCenter77 = NXOpen.Point3d(1.256827117752813, -2.1690403483798759, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-1.5710338971910423, 2.7113004354748322, 0.0)
    viewCenter78 = NXOpen.Point3d(1.5710338971910141, -2.7113004354748429, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-1.9637923714888026, 3.38912554434354, 0.0)
    viewCenter79 = NXOpen.Point3d(1.9637923714887702, -3.3891255443435533, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = -0.80411593512416835
    rotMatrix9.Xy = 0.26342995511070461
    rotMatrix9.Xz = -0.53291858818187188
    rotMatrix9.Yx = 0.033229690831436391
    rotMatrix9.Yy = 0.91497266494945295
    rotMatrix9.Yz = 0.40214525987825056
    rotMatrix9.Zx = 0.59354304858757634
    rotMatrix9.Zy = 0.30566269177914174
    rotMatrix9.Zz = -0.74449779605294897
    translation9 = NXOpen.Point3d(7.6909883415407378, 1.0146867745288741, -16.215345128109661)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 6.6826480863576778)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin12, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane8
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId86, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude2.FindObject("EDGE * 130 * 150 {(20,7,0)(10,7,0)(0,7,0) EXTRUDE(3)}")
    point14 = workPart.Points.CreatePoint(edge2, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge3 = extrude2.FindObject("EDGE * 120 * 150 {(20,0,0)(10,0,0)(0,0,0) EXTRUDE(3)}")
    direction6 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude2.FindObject("FACE 150 {(10,3.5,0) EXTRUDE(3)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction6, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem3
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin13, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = face2
    plane9.SetGeometry(geom6)
    
    plane9.SetFlip(False)
    
    plane9.SetExpression(None)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin14, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane10.SynchronizeToPlane(plane9)
    
    scalar4 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point15 = workPart.Points.CreatePoint(edge2, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane10.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane10.SetGeometry(geom7)
    
    plane10.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane10.Evaluate()
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId87, None)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject18 = sketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject18
    feature7 = sketch4.Feature
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId89)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.SetUndoMarkName(markId86, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression36)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point15)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression35)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane8.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression38)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression37)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    scaleAboutPoint80 = NXOpen.Point3d(14.886813138705287, -7.7205546862966434, 0.0)
    viewCenter80 = NXOpen.Point3d(-14.886813138705314, 7.7205546862966266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(11.909450510964223, -6.1764437490373147, 0.0)
    viewCenter81 = NXOpen.Point3d(-11.909450510964257, 6.1764437490372952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(7.6524554347046676, -3.8262277173523489, 0.0)
    viewCenter82 = NXOpen.Point3d(-7.652455434704696, 3.826227717352332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(9.0904582357625792, -4.529392082627365, 0.0)
    viewCenter83 = NXOpen.Point3d(-9.0904582357626129, 4.5293920826273464, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    origin15 = NXOpen.Point3d(0.65347773378398577, 0.64776515964407766, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin15)
    
    origin16 = NXOpen.Point3d(0.65347773378398577, 0.64776515964407766, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin16)
    
    scaleAboutPoint84 = NXOpen.Point3d(-10.610813620141036, 6.453591865981279, 0.0)
    viewCenter84 = NXOpen.Point3d(10.610813620141002, -6.4535918659812994, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-8.48865089611283, 5.1628734927850237, 0.0)
    viewCenter85 = NXOpen.Point3d(8.4886508961127962, -5.1628734927850433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId91, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(17.699999999999999, 1.0, 0.0)
    arc3 = workPart.Curves.CreateArc(center4, nXMatrix3, 1.8062248641773773, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = arc3
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(17.699999999999999, 1.2873112537408027, 0.0)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    expression39 = sketchDimensionalConstraint5.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId92, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center5 = NXOpen.Point3d(3.3331040987509368, 1.0, 0.0)
    arc4 = workPart.Curves.CreateArc(center5, nXMatrix4, 1.8739889398676575, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = arc4
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(3.3331040987509368, 1.2873112537408027, 0.0)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension6 = sketchDimensionalConstraint6.AssociatedDimension
    
    expression40 = sketchDimensionalConstraint6.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines25 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines28)
    
    theSession.SetUndoMarkName(markId93, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Destroy()
    
    theSession.UndoToMark(markId93, None)
    
    theSession.DeleteUndoMark(markId93, None)
    
    scaleAboutPoint86 = NXOpen.Point3d(-13.100395562060683, 8.4633116397064949, 0.0)
    viewCenter86 = NXOpen.Point3d(13.100395562060648, -8.4633116397065127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-16.375494452575854, 10.579139549633121, 0.0)
    viewCenter87 = NXOpen.Point3d(16.375494452575815, -10.579139549633137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    origin17 = NXOpen.Point3d(-0.44086140226360454, 3.9909633017513455, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin17)
    
    origin18 = NXOpen.Point3d(-0.44086140226360454, 3.9909633017513455, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin18)
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    diameterDimension3 = dimension5
    sketchRadialDimensionBuilder3 = workPart.Sketches.CreateRadialDimensionBuilder(diameterDimension3)
    
    sketchRadialDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId94, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits251 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits253 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits257 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRadialDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder3.Driving.ExpressionValue.SetFormula("1")
    
    sketchRadialDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject19 = sketchRadialDimensionBuilder3.Commit()
    
    point1_12 = NXOpen.Point3d(19.363312939153197, 5.3390772325735529, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    sketchRadialDimensionBuilder3.Driving.ExpressionValue.SetFormula("1")
    
    theSession.SetUndoMarkName(markId96, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    origin19 = NXOpen.Point3d(-0.52004657853332847, 9.0588145830128219, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin19)
    
    origin20 = NXOpen.Point3d(-0.52004657853332847, 9.0588145830128219, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin20)
    
    scaleAboutPoint88 = NXOpen.Point3d(-15.797442665806967, -5.3054068100705143, 0.0)
    viewCenter88 = NXOpen.Point3d(15.797442665806933, 5.3054068100704974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-12.637954132645577, -4.2443254480564079, 0.0)
    viewCenter89 = NXOpen.Point3d(12.637954132645543, 4.2443254480563946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-10.110363306116462, -3.3954603584451291, 0.0)
    viewCenter90 = NXOpen.Point3d(10.110363306116437, 3.395460358445114, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject20 = sketchRadialDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId98, None)
    
    theSession.SetUndoMarkName(markId94, "Radial Dimension")
    
    expression41 = sketchRadialDimensionBuilder3.Driving.ExpressionValue
    sketchRadialDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId96, None)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines33 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines36)
    
    theSession.SetUndoMarkName(markId99, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point1_13 = NXOpen.Point3d(19.096561888064514, 4.9161778630496178, 0.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc3, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(19.096561888064514, 4.9161778630496178, 0.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point16 = NXOpen.Point3d(18.541092312405961, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point16)
    
    point1_16 = NXOpen.Point3d(18.541092312405961, 0.0, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line1, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(19.096561888064514, 4.9161778630496178, 0.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc3, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(18.541092312405961, 0.0, 0.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line1, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(19.096561888064514, 4.9161778630496178, 0.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc3, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point17 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point17
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point18 = NXOpen.Point3d(20.993932332536467, 1.1181251066864029, 0.0)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point18)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = False
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId99, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId99, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId101, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression42 = workPart.Expressions.FindObject("p18")
    expression42.SetFormula("0.8")
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId101, "Edit Driving Value")
    
    point1_20 = NXOpen.Point3d(15.052200880557733, 4.9421976470319349, 0.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(15.052200880557733, 4.9421976470319349, 0.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point19 = NXOpen.Point3d(11.750171595515713, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point19)
    
    point1_23 = NXOpen.Point3d(11.750171595515713, 0.0, 0.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line1, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(15.052200880557733, 4.9421976470319349, 0.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(11.750171595515713, 0.0, 0.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line1, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(15.052200880557733, 4.9421976470319349, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point20 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point20
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point21 = NXOpen.Point3d(-2.6425260432665976, 0.89513965031090237, 0.0)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point21)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = False
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject22 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.SetUndoMarkName(markId103, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId103, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId105, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    expression43 = workPart.Expressions.FindObject("p19")
    expression43.SetFormula("0.8")
    
    theSession.SetUndoMarkVisibility(markId105, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId106, None)
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId105, "Edit Driving Value")
    
    point1_27 = NXOpen.Point3d(14.876963745355328, 1.4173762216794776, 0.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(14.876963745355328, 1.4173762216794776, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    edge4 = extrude2.FindObject("EDGE * 140 * 150 {(0,0,0)(0,3.5,0)(0,7,0) EXTRUDE(3)}")
    point1_30 = NXOpen.Point3d(0.0, 3.5, 0.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(14.876963745355328, 1.4173762216794776, 0.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(0.0, 3.5, 0.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    point1_33 = NXOpen.Point3d(14.876963745355328, 1.4173762216794776, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(0.0, 3.5, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point22 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point22
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point23 = NXOpen.Point3d(-1.9330268638900066, 4.2196500908183676, 0.0)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point23)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject23 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId108, None)
    
    theSession.SetUndoMarkName(markId107, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId107, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId109, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression44 = workPart.Expressions.FindObject("p20")
    expression44.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId109, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId110, None)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId109, "Edit Driving Value")
    
    point1_35 = NXOpen.Point3d(7.4958092326269714, 1.2999999999999998, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(7.4958092326269714, 1.2999999999999998, 0.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    edge5 = extrude2.FindObject("EDGE * 150 * 160 {(20,0,0)(20,3.5,0)(20,7,0) EXTRUDE(3)}")
    point24 = NXOpen.Point3d(20.0, 2.4357664398143628, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(edge5, workPart.ModelingViews.WorkView, point24)
    
    point1_38 = NXOpen.Point3d(20.0, 2.4357664398143628, 0.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge5, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    point1_39 = NXOpen.Point3d(7.4958092326269714, 1.2999999999999998, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(20.0, 2.4357664398143628, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge5, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    point1_41 = NXOpen.Point3d(7.4958092326269714, 1.2999999999999998, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point25 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point25
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point26 = NXOpen.Point3d(18.622177932906141, 8.1117598748271078, 0.0)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point26)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject24 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId112, None)
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId111, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression45 = workPart.Expressions.FindObject("p21")
    expression45.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId113, "Edit Driving Value")
    
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId115, None)
    
    theSession.DeleteUndoMark(markId115, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    scaleAboutPoint91 = NXOpen.Point3d(4.0137382147589955, -5.5746364093875238, 0.0)
    viewCenter91 = NXOpen.Point3d(-4.013738214759023, 5.5746364093875105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(3.2109905718071969, -4.4597091275100214, 0.0)
    viewCenter92 = NXOpen.Point3d(-3.2109905718072276, 4.459709127510008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(2.568792457445753, -3.5677673020080194, 0.0)
    viewCenter93 = NXOpen.Point3d(-2.5687924574457854, 3.5677673020080052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(3.2109905718071969, -4.4597091275100214, 0.0)
    viewCenter94 = NXOpen.Point3d(-3.2109905718072276, 4.459709127510008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(4.013738214758992, -5.5746364093875238, 0.0)
    viewCenter95 = NXOpen.Point3d(-4.0137382147590266, 5.5746364093875105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(0.10135702562521319, -7.9311872551740645, 0.0)
    viewCenter96 = NXOpen.Point3d(-0.10135702562524128, 7.9311872551740521, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-0.19004442304731253, -10.10402849201488, 0.0)
    viewCenter97 = NXOpen.Point3d(0.19004442304728822, 10.104028492014866, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-8.2748509201846119, -14.88681313870531, 0.0)
    viewCenter98 = NXOpen.Point3d(8.2748509201845852, 14.886813138705294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-6.619880736147695, -11.909450510964247, 0.0)
    viewCenter99 = NXOpen.Point3d(6.619880736147663, 11.909450510964232, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section3
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("0.8")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId116, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves4 = [NXOpen.ICurve.Null] * 2 
    curves4[0] = arc3
    curves4[1] = arc4
    seedPoint4 = NXOpen.Point3d(3.5187584826885892, 1.1458389884590607, 0.0)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves4, seedPoint4, 0.01)
    
    curves5 = [NXOpen.ICurve.Null] * 2 
    curves5[0] = arc3
    curves5[1] = arc4
    seedPoint5 = NXOpen.Point3d(16.833333333333336, 1.2999999999999998, 0.0)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves5, seedPoint5, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 2 
    rules3[0] = regionBoundaryRule4
    rules3[1] = regionBoundaryRule5
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId117, None)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId119, None)
    
    direction7 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction7
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies12)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId118, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies13)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature8 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId121, None)
    
    theSession.SetUndoMarkName(markId116, "Extrude")
    
    expression49 = extrudeBuilder4.Limits.StartExtend.Value
    expression50 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression46)
    
    workPart.Expressions.Delete(expression47)
    
    workPart.Expressions.Delete(expression48)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.69491537387903091
    rotMatrix10.Xy = -0.015409065041635087
    rotMatrix10.Xz = 0.71892641060202434
    rotMatrix10.Yx = 0.045647808648767094
    rotMatrix10.Yy = 0.99680868915419341
    rotMatrix10.Yz = 0.06548827980840892
    rotMatrix10.Zx = -0.71764120611356563
    rotMatrix10.Zy = 0.07832622767146119
    rotMatrix10.Zz = -0.691994292856976
    translation10 = NXOpen.Point3d(0.96313583839693084, -8.1131776655200731, 3.8222131928553029)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 10.441637634933871)
    
    scaleAboutPoint100 = NXOpen.Point3d(0.96289174343965067, -5.7013326914190587, 0.0)
    viewCenter100 = NXOpen.Point3d(-0.9628917434396701, 5.7013326914190463, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(1.2036146792995632, -7.1266658642738205, 0.0)
    viewCenter101 = NXOpen.Point3d(-1.2036146792995848, 7.1266658642738099, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.85874240545495528
    rotMatrix11.Xy = 0.010365449089930673
    rotMatrix11.Xz = 0.51230268254090283
    rotMatrix11.Yx = 0.066297006082312634
    rotMatrix11.Yy = 0.99363931686671658
    rotMatrix11.Yz = 0.09102535339765333
    rotMatrix11.Zx = -0.50810056884239285
    rotMatrix11.Zy = 0.11213146499448733
    rotMatrix11.Zz = -0.85396741536210308
    translation11 = NXOpen.Point3d(5.1190592409917217, -11.770947211665023, 3.2282197145642542)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 6.6826480863576778)
    
    scaleAboutPoint102 = NXOpen.Point3d(-2.6922959931701236, -5.5825549270144919, 0.0)
    viewCenter102 = NXOpen.Point3d(2.6922959931700965, 5.5825549270144821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.76287493556684116
    rotMatrix12.Xy = -0.17116954695202843
    rotMatrix12.Xz = 0.62347639801369392
    rotMatrix12.Yx = 0.21712409201837243
    rotMatrix12.Yy = 0.97614125070719937
    rotMatrix12.Yz = 0.0023210628996118178
    rotMatrix12.Zx = -0.60899832622848027
    rotMatrix12.Zy = 0.13360106610361991
    rotMatrix12.Zz = 0.78183872620054529
    translation12 = NXOpen.Point3d(-11.035019639173273, -11.214420949083994, -12.19600773108332)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 8.3533101079470971)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.94577025345336407
    rotMatrix13.Xy = -0.20113492691204821
    rotMatrix13.Xz = 0.25507522196177818
    rotMatrix13.Yx = 0.25676527716792885
    rotMatrix13.Yy = 0.94387939969061496
    rotMatrix13.Yz = -0.20775772255337308
    rotMatrix13.Zx = -0.19897291304004711
    rotMatrix13.Zy = 0.26198553398188273
    rotMatrix13.Zz = 0.94433752433152396
    translation13 = NXOpen.Point3d(-9.0750822276592746, -9.3971284674916635, -18.37059548185136)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 8.3533101079470971)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.92163582751022199
    rotMatrix14.Xy = -0.14276927581045931
    rotMatrix14.Xz = 0.36083837841075789
    rotMatrix14.Yx = 0.16765722209998069
    rotMatrix14.Yy = 0.98509488486203045
    rotMatrix14.Yz = -0.038459377223016497
    rotMatrix14.Zx = -0.34996922340009562
    rotMatrix14.Zy = 0.095942700103871847
    rotMatrix14.Zz = 0.93183503956951197
    translation14 = NXOpen.Point3d(-10.095649311573212, -10.3432855682157, -16.154457612057715)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 8.3533101079470971)
    
    scaleAboutPoint103 = NXOpen.Point3d(6.9366214412265021, -5.0678512812613832, 0.0)
    viewCenter103 = NXOpen.Point3d(-6.9366214412265244, 5.0678512812613725, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(8.7499619778028421, -6.3348141015767343, 0.0)
    viewCenter104 = NXOpen.Point3d(-8.7499619778028546, 6.3348141015767174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.98641287479408635
    rotMatrix15.Xy = -0.10424935410051421
    rotMatrix15.Xz = -0.12697130624708883
    rotMatrix15.Yx = 0.095762485898350361
    rotMatrix15.Yy = 0.99285306423722453
    rotMatrix15.Yz = -0.071220356144319291
    rotMatrix15.Zx = 0.13348852660447855
    rotMatrix15.Zy = 0.058093588324194735
    rotMatrix15.Zz = 0.98934622264432093
    translation15 = NXOpen.Point3d(-2.0784968090608551, -12.174548390509074, -21.431675051622683)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 5.346118469086143)
    
    # ----------------------------------------------
    #   Menu: Insert->Datum/Point->Datum Plane...
    # ----------------------------------------------
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    datumPlaneBuilder1 = workPart.Features.CreateDatumPlaneBuilder(NXOpen.Features.Feature.Null)
    
    plane11 = datumPlaneBuilder1.GetPlane()
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point27 = workPart.Points.CreatePoint(coordinates1)
    
    theSession.SetUndoMarkName(markId123, "Datum Plane Dialog")
    
    plane11.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face1
    plane11.SetGeometry(geom8)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(False)
    
    expression53 = plane11.Expression
    
    expression53.RightHandSide = "0"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face1
    plane11.SetGeometry(geom9)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(False)
    
    expression54 = plane11.Expression
    
    expression54.RightHandSide = "0"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates2 = NXOpen.Point3d(9.9999999999999982, 3.5, 20.0)
    point28 = workPart.Points.CreatePoint(coordinates2)
    
    workPart.Points.DeletePoint(point27)
    
    coordinates3 = NXOpen.Point3d(9.9999999999999982, 3.5, 20.0)
    point29 = workPart.Points.CreatePoint(coordinates3)
    
    workPart.Points.DeletePoint(point28)
    
    coordinates4 = NXOpen.Point3d(9.9999999999999982, 3.5, 20.0)
    point30 = workPart.Points.CreatePoint(coordinates4)
    
    workPart.Points.DeletePoint(point29)
    
    coordinates5 = NXOpen.Point3d(9.9999999999999982, 3.5, 20.0)
    point31 = workPart.Points.CreatePoint(coordinates5)
    
    workPart.Points.DeletePoint(point30)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.92371991219672589
    rotMatrix16.Xy = 0.083922463850398824
    rotMatrix16.Xz = -0.3737626838952125
    rotMatrix16.Yx = -0.31222336183741284
    rotMatrix16.Yy = 0.73024543285872046
    rotMatrix16.Yz = -0.60766617489533314
    rotMatrix16.Zx = 0.22194165029173255
    rotMatrix16.Zy = 0.67801078741437482
    rotMatrix16.Zz = 0.70074480091936719
    translation16 = NXOpen.Point3d(0.35774523056579532, -1.8111050158165396, -21.599902268061307)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 5.346118469086143)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face1
    plane11.SetGeometry(geom10)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(False)
    
    expression55 = plane11.Expression
    
    expression55.RightHandSide = "3"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates6 = NXOpen.Point3d(9.9999999999999982, 3.5, 23.0)
    point32 = workPart.Points.CreatePoint(coordinates6)
    
    workPart.Points.DeletePoint(point31)
    
    coordinates7 = NXOpen.Point3d(9.9999999999999982, 3.5, 23.0)
    point33 = workPart.Points.CreatePoint(coordinates7)
    
    workPart.Points.DeletePoint(point32)
    
    plane11.Evaluate()
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom11 = [NXOpen.NXObject.Null] * 1 
    geom11[0] = face1
    plane11.SetGeometry(geom11)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(True)
    
    expression56 = plane11.Expression
    
    expression56.RightHandSide = "3"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates8 = NXOpen.Point3d(9.9999999999999982, 3.5, 17.0)
    point34 = workPart.Points.CreatePoint(coordinates8)
    
    workPart.Points.DeletePoint(point33)
    
    coordinates9 = NXOpen.Point3d(9.9999999999999982, 3.5, 17.0)
    point35 = workPart.Points.CreatePoint(coordinates9)
    
    workPart.Points.DeletePoint(point34)
    
    plane11.Evaluate()
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face1
    plane11.SetGeometry(geom12)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(False)
    
    expression57 = plane11.Expression
    
    expression57.RightHandSide = "3"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates10 = NXOpen.Point3d(9.9999999999999982, 3.5, 23.0)
    point36 = workPart.Points.CreatePoint(coordinates10)
    
    workPart.Points.DeletePoint(point35)
    
    coordinates11 = NXOpen.Point3d(9.9999999999999982, 3.5, 23.0)
    point37 = workPart.Points.CreatePoint(coordinates11)
    
    workPart.Points.DeletePoint(point36)
    
    plane11.Evaluate()
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face1
    plane11.SetGeometry(geom13)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(True)
    
    expression58 = plane11.Expression
    
    expression58.RightHandSide = "3"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates12 = NXOpen.Point3d(9.9999999999999982, 3.5, 17.0)
    point38 = workPart.Points.CreatePoint(coordinates12)
    
    workPart.Points.DeletePoint(point37)
    
    coordinates13 = NXOpen.Point3d(9.9999999999999982, 3.5, 17.0)
    point39 = workPart.Points.CreatePoint(coordinates13)
    
    workPart.Points.DeletePoint(point38)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.10663934146714506
    rotMatrix17.Xy = -0.52903768655842798
    rotMatrix17.Xz = -0.84187123543470921
    rotMatrix17.Yx = -0.10166239997543047
    rotMatrix17.Yy = 0.8364605502561635
    rotMatrix17.Yz = -0.53851509198572611
    rotMatrix17.Zx = 0.98908685527747808
    rotMatrix17.Zy = 0.14301354504405059
    rotMatrix17.Zz = 0.035416361349583717
    translation17 = NXOpen.Point3d(15.354996979687458, -4.9799783744234842, -20.7455795739248)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 5.346118469086143)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom14 = [NXOpen.NXObject.Null] * 1 
    geom14[0] = face1
    plane11.SetGeometry(geom14)
    
    plane11.SetFlip(False)
    
    plane11.SetReverseSide(True)
    
    expression59 = plane11.Expression
    
    expression59.RightHandSide = "4"
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    coordinates14 = NXOpen.Point3d(9.9999999999999982, 3.5, 16.0)
    point40 = workPart.Points.CreatePoint(coordinates14)
    
    workPart.Points.DeletePoint(point39)
    
    coordinates15 = NXOpen.Point3d(9.9999999999999982, 3.5, 16.0)
    point41 = workPart.Points.CreatePoint(coordinates15)
    
    workPart.Points.DeletePoint(point40)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    theSession.DeleteUndoMark(markId124, None)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    plane11.RemoveOffsetData()
    
    plane11.Evaluate()
    
    corner1_1 = NXOpen.Point3d(-0.50000000000000178, -0.5, 16.0)
    corner2_1 = NXOpen.Point3d(20.5, -0.5, 16.0)
    corner3_1 = NXOpen.Point3d(20.5, 7.5, 16.0)
    corner4_1 = NXOpen.Point3d(-0.50000000000000178, 7.5, 16.0)
    datumPlaneBuilder1.SetCornerPoints(corner1_1, corner2_1, corner3_1, corner4_1)
    
    datumPlaneBuilder1.ResizeDuringUpdate = True
    
    feature9 = datumPlaneBuilder1.CommitFeature()
    
    datumPlaneFeature1 = feature9
    datumPlane2 = datumPlaneFeature1.DatumPlane
    
    datumPlane2.SetReverseSection(False)
    
    theSession.DeleteUndoMark(markId125, None)
    
    theSession.SetUndoMarkName(markId123, "Datum Plane")
    
    datumPlaneBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression52)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.42210221805433429
    rotMatrix18.Xy = -0.46637259110908758
    rotMatrix18.Xz = -0.77738428320606712
    rotMatrix18.Yx = -0.66621432962657168
    rotMatrix18.Yy = 0.74113957768658667
    rotMatrix18.Yz = -0.082889042621858006
    rotMatrix18.Zx = 0.61480743693764073
    rotMatrix18.Zy = 0.48291690035527624
    rotMatrix18.Zz = -0.62354076277130821
    translation18 = NXOpen.Point3d(19.778215218543139, -3.5570961675572343, -11.602875892906802)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 5.346118469086143)
    
    # ----------------------------------------------
    #   Menu: Insert->Datum/Point->Datum Plane...
    # ----------------------------------------------
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    datumPlaneBuilder2 = workPart.Features.CreateDatumPlaneBuilder(NXOpen.Features.Feature.Null)
    
    plane12 = datumPlaneBuilder2.GetPlane()
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    coordinates16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point42 = workPart.Points.CreatePoint(coordinates16)
    
    theSession.SetUndoMarkName(markId126, "Datum Plane Dialog")
    
    plane12.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face2
    plane12.SetGeometry(geom15)
    
    plane12.SetFlip(False)
    
    plane12.SetReverseSide(False)
    
    expression62 = plane12.Expression
    
    expression62.RightHandSide = "4"
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom16 = [NXOpen.NXObject.Null] * 1 
    geom16[0] = face2
    plane12.SetGeometry(geom16)
    
    plane12.SetFlip(False)
    
    plane12.SetReverseSide(False)
    
    expression63 = plane12.Expression
    
    expression63.RightHandSide = "4"
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    coordinates17 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point43 = workPart.Points.CreatePoint(coordinates17)
    
    workPart.Points.DeletePoint(point42)
    
    coordinates18 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point44 = workPart.Points.CreatePoint(coordinates18)
    
    workPart.Points.DeletePoint(point43)
    
    coordinates19 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point45 = workPart.Points.CreatePoint(coordinates19)
    
    workPart.Points.DeletePoint(point44)
    
    coordinates20 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point46 = workPart.Points.CreatePoint(coordinates20)
    
    workPart.Points.DeletePoint(point45)
    
    plane12.Evaluate()
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom17 = [NXOpen.NXObject.Null] * 1 
    geom17[0] = face2
    plane12.SetGeometry(geom17)
    
    plane12.SetFlip(False)
    
    plane12.SetReverseSide(True)
    
    expression64 = plane12.Expression
    
    expression64.RightHandSide = "4"
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    coordinates21 = NXOpen.Point3d(10.0, 3.5, 4.0)
    point47 = workPart.Points.CreatePoint(coordinates21)
    
    workPart.Points.DeletePoint(point46)
    
    coordinates22 = NXOpen.Point3d(10.0, 3.5, 4.0)
    point48 = workPart.Points.CreatePoint(coordinates22)
    
    workPart.Points.DeletePoint(point47)
    
    plane12.Evaluate()
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face2
    plane12.SetGeometry(geom18)
    
    plane12.SetFlip(False)
    
    plane12.SetReverseSide(False)
    
    expression65 = plane12.Expression
    
    expression65.RightHandSide = "4"
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    coordinates23 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point49 = workPart.Points.CreatePoint(coordinates23)
    
    workPart.Points.DeletePoint(point48)
    
    coordinates24 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point50 = workPart.Points.CreatePoint(coordinates24)
    
    workPart.Points.DeletePoint(point49)
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    theSession.DeleteUndoMark(markId127, None)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    plane12.RemoveOffsetData()
    
    plane12.Evaluate()
    
    corner1_2 = NXOpen.Point3d(20.5, -0.5, -4.0)
    corner2_2 = NXOpen.Point3d(-0.50000000000000178, -0.5, -4.0)
    corner3_2 = NXOpen.Point3d(-0.50000000000000178, 7.5, -4.0)
    corner4_2 = NXOpen.Point3d(20.5, 7.5, -4.0)
    datumPlaneBuilder2.SetCornerPoints(corner1_2, corner2_2, corner3_2, corner4_2)
    
    datumPlaneBuilder2.ResizeDuringUpdate = True
    
    feature10 = datumPlaneBuilder2.CommitFeature()
    
    datumPlaneFeature2 = feature10
    datumPlane3 = datumPlaneFeature2.DatumPlane
    
    datumPlane3.SetReverseSection(False)
    
    theSession.DeleteUndoMark(markId128, None)
    
    theSession.SetUndoMarkName(markId126, "Datum Plane")
    
    datumPlaneBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression61)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression60)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    extrude3 = feature8
    editWithRollbackManager2 = workPart.Features.StartEditWithRollbackManager(extrude3, markId129)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(extrude3)
    
    section3.PrepareMappingData()
    
    refs2 = section3.EvaluateAndAskOutputEntities()
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies14)
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies15)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    expression67 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.SetUndoMarkName(markId130, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    expression69 = extrudeBuilder5.Limits.StartExtend.Value
    expression70 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression66)
    
    workPart.Expressions.Delete(expression67)
    
    workPart.Expressions.Delete(expression68)
    
    theSession.UndoToMark(markId130, None)
    
    theSession.DeleteUndoMark(markId130, None)
    
    theSession.DeleteUndoMark(markId130, None)
    
    editWithRollbackManager2.UpdateFeature(True)
    
    editWithRollbackManager2.Stop()
    
    theSession.UndoToMarkWithStatus(markId129, None)
    
    theSession.DeleteUndoMarksUpToMark(markId129, None, False)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    editWithRollbackManager3 = workPart.Features.StartEditWithRollbackManager(datumPlaneFeature2, markId131)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    datumPlaneBuilder3 = workPart.Features.CreateDatumPlaneBuilder(datumPlaneFeature2)
    
    plane13 = datumPlaneBuilder3.GetPlane()
    
    expression71 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression72 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane13.Evaluate()
    
    coordinates25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point51 = workPart.Points.CreatePoint(coordinates25)
    
    coordinates26 = NXOpen.Point3d(10.0, 3.5, -4.0)
    point52 = workPart.Points.CreatePoint(coordinates26)
    
    workPart.Points.DeletePoint(point51)
    
    theSession.SetUndoMarkName(markId132, "Datum Plane Dialog")
    
    plane13.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    plane13.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    # ----------------------------------------------
    #   Dialog Begin Datum Plane
    # ----------------------------------------------
    selectedObjects1 = [NXOpen.NXObject.Null] * 1 
    selectedObjects1[0] = datumPlaneFeature2
    theSession.Information.DisplayObjectsDetails(selectedObjects1)
    
    plane13.Evaluate()
    
    plane13.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom19 = [NXOpen.NXObject.Null] * 1 
    geom19[0] = face2
    plane13.SetGeometry(geom19)
    
    plane13.SetFlip(False)
    
    plane13.SetReverseSide(True)
    
    expression73 = plane13.Expression
    
    expression73.RightHandSide = "4"
    
    plane13.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane13.Evaluate()
    
    coordinates27 = NXOpen.Point3d(10.0, 3.5, 4.0)
    point53 = workPart.Points.CreatePoint(coordinates27)
    
    workPart.Points.DeletePoint(point52)
    
    coordinates28 = NXOpen.Point3d(10.0, 3.5, 4.0)
    point54 = workPart.Points.CreatePoint(coordinates28)
    
    workPart.Points.DeletePoint(point53)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    theSession.DeleteUndoMark(markId133, None)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    plane13.RemoveOffsetData()
    
    plane13.Evaluate()
    
    corner1_3 = NXOpen.Point3d(20.5, -0.5, 4.0)
    corner2_3 = NXOpen.Point3d(-0.50000000000000178, -0.5, 4.0)
    corner3_3 = NXOpen.Point3d(-0.50000000000000178, 7.5, 4.0)
    corner4_3 = NXOpen.Point3d(20.5, 7.5, 4.0)
    datumPlaneBuilder3.SetCornerPoints(corner1_3, corner2_3, corner3_3, corner4_3)
    
    datumPlaneBuilder3.ResizeDuringUpdate = True
    
    feature11 = datumPlaneBuilder3.CommitFeature()
    
    datumPlaneFeature3 = feature11
    datumPlane4 = datumPlaneFeature3.DatumPlane
    
    datumPlane4.SetReverseSection(False)
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId132, "Datum Plane")
    
    datumPlaneBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression72)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression71)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    theSession.DeleteUndoMark(markId132, None)
    
    editWithRollbackManager3.UpdateFeature(False)
    
    editWithRollbackManager3.Stop()
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    editWithRollbackManager3.Destroy()
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.55811882679933211
    rotMatrix19.Xy = 0.21772620474291193
    rotMatrix19.Xz = -0.8006863773915408
    rotMatrix19.Yx = -0.40038362131613436
    rotMatrix19.Yy = 0.91585495546091389
    rotMatrix19.Yz = -0.030044239705320816
    rotMatrix19.Zx = 0.72677116821866139
    rotMatrix19.Zy = 0.33734996713493381
    rotMatrix19.Zz = 0.59832989957058502
    translation19 = NXOpen.Point3d(7.8146799263792213, -7.3553551020371248, -24.431735562864748)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 5.346118469086143)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Redefine Feature")
    
    editWithRollbackManager4 = workPart.Features.StartEditWithRollbackManager(datumPlaneFeature1, markId135)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    datumPlaneBuilder4 = workPart.Features.CreateDatumPlaneBuilder(datumPlaneFeature1)
    
    plane14 = datumPlaneBuilder4.GetPlane()
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane14.Evaluate()
    
    coordinates29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point55 = workPart.Points.CreatePoint(coordinates29)
    
    coordinates30 = NXOpen.Point3d(10.0, 3.5, 16.0)
    point56 = workPart.Points.CreatePoint(coordinates30)
    
    workPart.Points.DeletePoint(point55)
    
    theSession.SetUndoMarkName(markId136, "Datum Plane Dialog")
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    plane14.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    # ----------------------------------------------
    #   Dialog Begin Datum Plane
    # ----------------------------------------------
    datumPlaneBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression75)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression74)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    theSession.UndoToMark(markId136, None)
    
    theSession.DeleteUndoMark(markId136, None)
    
    theSession.DeleteUndoMark(markId136, None)
    
    editWithRollbackManager4.UpdateFeature(True)
    
    editWithRollbackManager4.Stop()
    
    theSession.UndoToMarkWithStatus(markId135, None)
    
    theSession.DeleteUndoMarksUpToMark(markId135, None, False)
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin21, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane15
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId137, "Create Sketch Dialog")
    
    scaleAboutPoint105 = NXOpen.Point3d(-2.8209719046083936, -1.5837035253941838, 0.0)
    viewCenter105 = NXOpen.Point3d(2.8209719046083768, 1.5837035253941711, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-2.2171849355518622, -1.3065554084502093, 0.0)
    viewCenter106 = NXOpen.Point3d(2.2171849355518485, 1.3065554084501925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-1.7420738779336107, -1.0452443267601648, 0.0)
    viewCenter107 = NXOpen.Point3d(1.7420738779335945, 1.0452443267601512, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(-1.3936591023468885, -0.83619546140813183, 0.0)
    viewCenter108 = NXOpen.Point3d(1.3936591023468714, 0.83619546140812107, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scalar5 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge6 = extrude2.FindObject("EDGE * 130 * 170 {(0,7,20)(10,7,20)(20,7,20) EXTRUDE(3)}")
    point57 = workPart.Points.CreatePoint(edge6, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction8 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane2, direction8, point57, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem4
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin22, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane16.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom20 = [NXOpen.NXObject.Null] * 1 
    geom20[0] = datumPlane2
    plane16.SetGeometry(geom20)
    
    plane16.SetFlip(False)
    
    plane16.SetExpression(None)
    
    plane16.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane16.Evaluate()
    
    origin23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin23, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane17.SynchronizeToPlane(plane16)
    
    scalar6 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point58 = workPart.Points.CreatePoint(edge6, scalar6, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane17.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom21 = [NXOpen.NXObject.Null] * 1 
    geom21[0] = datumPlane2
    plane17.SetGeometry(geom21)
    
    plane17.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane17.Evaluate()
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject25 = sketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject25
    feature12 = sketch5.Feature
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId140)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.SetUndoMarkName(markId137, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression77)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point58)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression76)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression79)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression78)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    origin24 = NXOpen.Point3d(19.156477843168492, 3.9795606363683569, 16.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin24)
    
    origin25 = NXOpen.Point3d(19.156477843168492, 3.9795606363683569, 16.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin25)
    
    scaleAboutPoint109 = NXOpen.Point3d(3.6083101122580912, -3.2636962251323349, 0.0)
    viewCenter109 = NXOpen.Point3d(-3.608310112258108, 3.2636962251323212, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(2.8866480898064695, -2.6109569801058692, 0.0)
    viewCenter110 = NXOpen.Point3d(-2.8866480898064917, 2.6109569801058536, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId142, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint5 = NXOpen.Point3d(19.999999999999996, 2.7008404010804865, 16.0)
    endPoint5 = NXOpen.Point3d(27.386058147591548, 1.3984790685784692, 16.0)
    line7 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line7
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    edge7 = extrude2.FindObject("EDGE * 160 * 170 {(20,0,20)(20,3.5,20)(20,7,20) EXTRUDE(3)}")
    conGeom2_5.Geometry = edge7
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 19.999999999999996
    help1.Point.Y = 2.7008404010804865
    help1.Point.Z = 16.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_5, conGeom2_5, help1)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line7
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line7
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(23.61639638161996, 1.6150541409044603, 16.0)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_3, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression80 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line7
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 27.386058147591548
    dimObject1_8.HelpPoint.Y = 1.3984790685784692
    dimObject1_8.HelpPoint.Z = 16.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis3 = workPart.Datums.FindObject("SKETCH(10:1B) X axis")
    dimObject2_4.Geometry = datumAxis3
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 28.575000000000003
    dimObject2_4.HelpPoint.Y = 7.0
    dimObject2_4.HelpPoint.Z = 16.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(20.721547312333019, 4.80374644661463, 16.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_8, dimObject2_4, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension8 = sketchDimensionalConstraint8.AssociatedDimension
    
    expression81 = sketchDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId143, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint6 = NXOpen.Point3d(27.386058147591548, 1.3984790685784692, 16.0)
    endPoint6 = NXOpen.Point3d(27.386058147591548, -0.39467138798667367, 16.0)
    line8 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line8
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line7
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom22.Geometry = line8
    geom22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateVerticalConstraint(geom22)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line8
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line8
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(26.944748061845676, 0.50190384029589774, 16.0)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_5, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression82 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId144, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint7 = NXOpen.Point3d(27.386058147591548, -0.39467138798667367, 16.0)
    endPoint7 = NXOpen.Point3d(19.990459966713871, 0.90937210978053606, 16.0)
    line9 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line9
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line8
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line9
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = edge7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 19.999999999999996
    help2.Point.Y = 0.96236469755658316
    help2.Point.Z = 16.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_6, conGeom2_6, help2)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line9
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line7
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateParallelConstraint(conGeom1_7, conGeom2_7)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line9
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line9
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(23.76489174932852, 0.69195595482194872, 16.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_6, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression83 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId145, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint8 = NXOpen.Point3d(19.999999999999996, 2.7008404010804865, 16.0)
    endPoint8 = NXOpen.Point3d(19.999999999999993, 0.90768994451534191, 16.0)
    line10 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line10
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line7
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom23.Geometry = line10
    geom23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreateVerticalConstraint(geom23)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line10
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line9
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension3)
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId146, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits441 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits443 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits447 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits451 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId147, None)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point59 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin9.PointOnGeometry = point59
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point60 = NXOpen.Point3d(23.685920604308667, 1.5072600673178069, 16.0)
    sketchLinearDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point60)
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder5.Style.DimensionStyle.TextCentered = True
    
    dimensionlinearunits459 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits465 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits469 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchLinearDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId148, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId148, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder5.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    nXObject26 = sketchLinearDimensionBuilder5.Commit()
    
    point1_42 = NXOpen.Point3d(19.999999999999996, 2.7008404010804865, 16.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(25.908846518073247, 1.6589513350789069, 16.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    theSession.SetUndoMarkName(markId149, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId149, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject27 = sketchLinearDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId151, None)
    
    theSession.SetUndoMarkName(markId146, "Linear Dimension")
    
    expression84 = sketchLinearDimensionBuilder5.Driving.ExpressionValue
    sketchLinearDimensionBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId150, None)
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId149, None)
    
    theSession.DeleteUndoMark(markId148, None)
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension4 = dimension9
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension4)
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId152, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits471 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits473 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits477 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchLinearDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId153, None)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("2")
    
    sketchLinearDimensionBuilder6.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    nXObject28 = sketchLinearDimensionBuilder6.Commit()
    
    point1_44 = NXOpen.Point3d(25.908846518073247, 1.6589513350789069, 16.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, NXOpen.View.Null, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(25.908846518073247, -0.3410486649210922, 16.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line8, NXOpen.View.Null, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    sketchLinearDimensionBuilder6.Driving.ExpressionValue.SetFormula("2")
    
    theSession.SetUndoMarkName(markId154, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject29 = sketchLinearDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.SetUndoMarkName(markId152, "Linear Dimension")
    
    expression85 = sketchLinearDimensionBuilder6.Driving.ExpressionValue
    sketchLinearDimensionBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId155, None)
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId154, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines57 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines60)
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    point1_46 = NXOpen.Point3d(19.999999999999996, 0.7008404010804874, 16.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(19.999999999999996, 0.0, 20.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(19.999999999999996, 0.7008404010804874, 16.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(19.999999999999996, 0.0, 20.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point61 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point61
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point62 = NXOpen.Point3d(21.1171281468629, -1.1264008865281081, 16.0)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point62)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject30 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId157, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId159, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression86 = workPart.Expressions.FindObject("p32")
    expression86.SetFormula("0.8")
    
    theSession.SetUndoMarkVisibility(markId159, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId159, "Edit Driving Value")
    
    sketchRapidDimensionBuilder12.Destroy()
    
    theSession.UndoToMark(markId161, None)
    
    theSession.DeleteUndoMark(markId161, None)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section4
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression87 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("0.8")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId162, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves6 = [NXOpen.ICurve.Null] * 4 
    curves6[0] = line7
    curves6[1] = line8
    curves6[2] = line9
    curves6[3] = line10
    seedPoint6 = NXOpen.Point3d(23.939231012048829, 0.77207395599894735, 16.0)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves6, seedPoint6, 0.01)
    
    section4.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = regionBoundaryRule6
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId163, None)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId165, None)
    
    direction9 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction9
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies19)
    
    expression88 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId164, None)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies20)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.77686984477729448
    rotMatrix20.Xy = -0.016559252696974482
    rotMatrix20.Xz = -0.6294434330627503
    rotMatrix20.Yx = -0.065663731960870012
    rotMatrix20.Yy = 0.99207295760032976
    rotMatrix20.Yz = -0.10714252705207655
    rotMatrix20.Zx = 0.62622800846071558
    rotMatrix20.Zy = 0.12456740323315596
    rotMatrix20.Zz = 0.76962422224815308
    translation20 = NXOpen.Point3d(-11.27574120206007, -0.87478428203885272, -22.032401789130461)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 20.393823505730214)
    
    extrudeBuilder6.Limits.SymmetricOption = True
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0.8")
    
    extrudeBuilder6.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder6.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder6.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("1")
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("1")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies22)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId166, None)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature13 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId167, None)
    
    theSession.SetUndoMarkName(markId162, "Extrude")
    
    expression89 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression87)
    
    workPart.Expressions.Delete(expression88)
    
    scaleAboutPoint111 = NXOpen.Point3d(-0.77842195680175696, -2.5428450588857174, 0.0)
    viewCenter111 = NXOpen.Point3d(0.7784219568017392, 2.5428450588857019, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-0.62273756544140901, -2.0342760471085763, 0.0)
    viewCenter112 = NXOpen.Point3d(0.62273756544138692, 2.0342760471085595, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-0.49819005235313002, -1.6274208376868615, 0.0)
    viewCenter113 = NXOpen.Point3d(0.49819005235310732, 1.6274208376868453, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-0.62273756544140735, -2.0342760471085768, 0.0)
    viewCenter114 = NXOpen.Point3d(0.62273756544138703, 2.0342760471085599, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(-0.77842195680176107, -2.5428450588857165, 0.0)
    viewCenter115 = NXOpen.Point3d(0.77842195680173676, 2.542845058885701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-2.7244768488061286, -3.0488193308068521, 0.0)
    viewCenter116 = NXOpen.Point3d(2.7244768488061051, 3.048819330806837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-3.446138871257749, -3.8110241635085633, 0.0)
    viewCenter117 = NXOpen.Point3d(3.4461388712577268, 3.8110241635085478, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-4.3076735890721869, -4.7637802043857018, 0.0)
    viewCenter118 = NXOpen.Point3d(4.3076735890721602, 4.7637802043856894, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint118, viewCenter118)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = -0.90119205907879707
    rotMatrix21.Xy = -0.090024670857220185
    rotMatrix21.Xz = -0.42396748848275462
    rotMatrix21.Yx = -0.12002416500497672
    rotMatrix21.Yy = 0.99177161413509463
    rotMatrix21.Yz = 0.044533865885732923
    rotMatrix21.Zx = 0.41646977377498023
    rotMatrix21.Zy = 0.091019910090701775
    rotMatrix21.Zz = -0.90458183902779288
    translation21 = NXOpen.Point3d(5.4312591806690094, -5.2414927487484784, -2.508067554856515)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 8.3533101079470971)
    
    scaleAboutPoint119 = NXOpen.Point3d(-14.28500579905552, -2.9456885572331823, 0.0)
    viewCenter119 = NXOpen.Point3d(14.285005799055504, 2.945688557233169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-11.529361664869645, -2.3312115893802408, 0.0)
    viewCenter120 = NXOpen.Point3d(11.529361664869633, 2.3312115893802274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-9.2234893318957187, -1.8649692715041941, 0.0)
    viewCenter121 = NXOpen.Point3d(9.2234893318957063, 1.8649692715041803, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-7.4112257137166475, -1.4919754172033566, 0.0)
    viewCenter122 = NXOpen.Point3d(7.411225713716636, 1.4919754172033426, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-9.3856605728960787, -1.8244264612541028, 0.0)
    viewCenter123 = NXOpen.Point3d(9.3856605728960645, 1.824426461254089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-11.75741497252641, -2.280533076567627, 0.0)
    viewCenter124 = NXOpen.Point3d(11.757414972526393, 2.2805330765676142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-14.728442786165882, -2.8506663457095325, 0.0)
    viewCenter125 = NXOpen.Point3d(14.728442786165871, 2.8506663457095134, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-18.370960894572502, -3.4445551677323523, 0.0)
    viewCenter126 = NXOpen.Point3d(18.37096089457248, 3.4445551677323323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-22.963701118215624, -4.3056939596654358, 0.0)
    viewCenter127 = NXOpen.Point3d(22.963701118215607, 4.3056939596654189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-28.70462639776953, -5.3821174495817896, 0.0)
    viewCenter128 = NXOpen.Point3d(28.704626397769509, 5.382117449581779, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint128, viewCenter128)
    
    origin26 = NXOpen.Point3d(-4.6164399056494219, 8.8279069450429049, -4.0097642745951747)
    workPart.ModelingViews.WorkView.SetOrigin(origin26)
    
    origin27 = NXOpen.Point3d(-4.6164399056494219, 8.8279069450429049, -4.0097642745951747)
    workPart.ModelingViews.WorkView.SetOrigin(origin27)
    
    scaleAboutPoint129 = NXOpen.Point3d(-24.513379763181401, -4.7944149694550413, 0.0)
    viewCenter129 = NXOpen.Point3d(24.513379763181401, 4.794414969455028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-19.610703810545125, -3.8355319755640389, 0.0)
    viewCenter130 = NXOpen.Point3d(19.610703810545125, 3.8355319755640176, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(-15.688563048436096, -3.068425580451231, 0.0)
    viewCenter131 = NXOpen.Point3d(15.688563048436096, 3.0684255804512102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin28, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane18
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId169, "Create Sketch Dialog")
    
    scalar7 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point63 = workPart.Points.CreatePoint(edge4, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction10 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane4, direction10, point63, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem5
    
    origin29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin29, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane19.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom24 = [NXOpen.NXObject.Null] * 1 
    geom24[0] = datumPlane4
    plane19.SetGeometry(geom24)
    
    plane19.SetFlip(False)
    
    plane19.SetExpression(None)
    
    plane19.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane19.Evaluate()
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane20 = workPart.Planes.CreatePlane(origin30, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane20.SynchronizeToPlane(plane19)
    
    scalar8 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point64 = workPart.Points.CreatePoint(edge4, scalar8, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane20.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom25 = [NXOpen.NXObject.Null] * 1 
    geom25[0] = datumPlane4
    plane20.SetGeometry(geom25)
    
    plane20.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane20.Evaluate()
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId170, None)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject31 = sketchInPlaceBuilder6.Commit()
    
    sketch6 = nXObject31
    feature14 = sketch6.Feature
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId172)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId171, None)
    
    theSession.SetUndoMarkName(markId169, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression91)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point64)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression90)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane18.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression93)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression92)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane20.DestroyPlane()
    
    scaleAboutPoint132 = NXOpen.Point3d(-24.111886174126397, -6.8891103354646983, 0.0)
    viewCenter132 = NXOpen.Point3d(24.111886174126397, 6.8891103354646743, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(-20.334753266061277, -4.7194365056746701, 0.0)
    viewCenter133 = NXOpen.Point3d(20.334753266061277, 4.7194365056746461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(-26.80418216729651, -5.1470364575310992, 0.0)
    viewCenter134 = NXOpen.Point3d(26.804182167296506, 5.1470364575310752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(-18.687701599651341, -3.7692143904381621, 0.0)
    viewCenter135 = NXOpen.Point3d(18.687701599651326, 3.7692143904381377, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(-14.950161279721071, -3.0153715123505322, 0.0)
    viewCenter136 = NXOpen.Point3d(14.950161279721062, 3.0153715123505065, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint136, viewCenter136)
    
    origin31 = NXOpen.Point3d(14.969165722025799, 4.2738127513865116, 4.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin31)
    
    origin32 = NXOpen.Point3d(14.969165722025799, 4.2738127513865116, 4.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin32)
    
    scaleAboutPoint137 = NXOpen.Point3d(-8.7775184191447071, -1.9663262971294255, 0.0)
    viewCenter137 = NXOpen.Point3d(8.7775184191447071, 1.9663262971294013, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-7.0220147353157643, -1.5730610377035434, 0.0)
    viewCenter138 = NXOpen.Point3d(7.0220147353157696, 1.5730610377035186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint138, viewCenter138)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId174, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint9 = NXOpen.Point3d(19.999999999999996, 2.7999999999999998, 4.0)
    endPoint9 = NXOpen.Point3d(20.0, 0.82848473633377662, 4.0)
    line11 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line11
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude4 = feature13
    edge8 = extrude4.FindObject("EDGE * 120 * 170 {(25.9088465180732,1.7581109339984,15)(22.9544232590366,2.2790554669992,15)(20,2.8,15) EXTRUDE(3)}")
    geom2_10.Geometry = edge8
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom26.Geometry = line11
    geom26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreateVerticalConstraint(geom26)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line11
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = edge5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 20.0
    help3.Point.Y = 0.82848473633377662
    help3.Point.Z = 4.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_8, conGeom2_8, help3)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line11
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line11
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(20.441310085745872, 1.8142423681668891, 4.0)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_7, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint11
    dimension11 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression94 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId176, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint10 = NXOpen.Point3d(20.0, 0.82848473633377662, 4.0)
    endPoint10 = NXOpen.Point3d(25.913782221253268, -0.21427462730720137, 4.0)
    line12 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line12
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line12
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    edge9 = extrude4.FindObject("EDGE * 120 * 150 {(20,0.8,15)(22.9544232590366,0.2790554669992,15)(25.9088465180732,-0.2418890660016,15) EXTRUDE(3)}")
    geom2_12.Geometry = edge9
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line12
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    edge10 = extrude4.FindObject("EDGE * 130 * 150 {(20,0.8,17)(22.9544232590366,0.2790554669992,17)(25.9088465180732,-0.2418890660016,17) EXTRUDE(3)}")
    conGeom2_9.Geometry = edge10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateParallelConstraint(conGeom1_9, conGeom2_9)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId177, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint11 = NXOpen.Point3d(25.908846518073247, -0.241889066001578, 4.0)
    endPoint11 = NXOpen.Point3d(25.908846518073247, 1.7581109339984211, 4.0)
    line13 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line13
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line12
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom27.Geometry = line13
    geom27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateVerticalConstraint(geom27)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line13
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = edge8
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId178, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint12 = NXOpen.Point3d(25.908846518073247, 1.7581109339984211, 4.0)
    endPoint12 = NXOpen.Point3d(19.999999999999996, 2.7999999999999989, 4.0)
    line14 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line14
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line13
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line14
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    edge11 = extrude4.FindObject("EDGE * 130 * 170 {(25.9088465180732,1.7581109339984,17)(22.9544232590366,2.2790554669992,17)(20,2.8,17) EXTRUDE(3)}")
    conGeom2_10.Geometry = edge11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreateCollinearConstraint(conGeom1_10, conGeom2_10)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line14
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line11
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = -0.9721691595949512
    rotMatrix22.Xy = 0.014337681247578504
    rotMatrix22.Xz = -0.23384087758321892
    rotMatrix22.Yx = -0.023677085951363759
    rotMatrix22.Yy = 0.98700237104931199
    rotMatrix22.Yz = 0.15895192714745171
    rotMatrix22.Zx = 0.23308050268801733
    rotMatrix22.Zy = 0.1600648319884162
    rotMatrix22.Zz = -0.95919379106999181
    translation22 = NXOpen.Point3d(20.063724468223114, -4.8091591331003292, 0.070557639162866614)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 20.393823505730229)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section5
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("1")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("1")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("1")
    
    smartVolumeProfileBuilder5 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId179, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves7 = [NXOpen.ICurve.Null] * 4 
    curves7[0] = line11
    curves7[1] = line13
    curves7[2] = line12
    curves7[3] = line14
    seedPoint7 = NXOpen.Point3d(21.969615506024414, 1.7860369779994729, 4.0)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves7, seedPoint7, 0.01)
    
    section5.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule7
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId180, None)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId182, None)
    
    direction11 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction11
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies26)
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId181, None)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder7.Limits.SymmetricOption = True
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("1")
    
    extrudeBuilder7.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.StartExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies28)
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId183, None)
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature15 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId184, None)
    
    theSession.SetUndoMarkName(markId179, "Extrude")
    
    expression97 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression95)
    
    workPart.Expressions.Delete(expression96)
    
    scaleAboutPoint139 = NXOpen.Point3d(-8.108562050018211, -0.84329045320190654, 0.0)
    viewCenter139 = NXOpen.Point3d(8.1085620500182056, 0.84329045320188112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(-9.4708004744212673, -1.2487185557028162, 0.0)
    viewCenter140 = NXOpen.Point3d(9.470800474421269, 1.2487185557027913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(-11.351986870025486, -1.7433408407539255, 0.0)
    viewCenter141 = NXOpen.Point3d(11.35198687002549, 1.7433408407539013, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(-6.7149029476713222, -3.0660500251631455, 0.0)
    viewCenter142 = NXOpen.Point3d(6.7149029476713311, 3.0660500251631193, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(-8.3936286845891548, -3.8325625314539282, 0.0)
    viewCenter143 = NXOpen.Point3d(8.3936286845891601, 3.8325625314539042, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(-10.492035855736447, -4.7907031643174101, 0.0)
    viewCenter144 = NXOpen.Point3d(10.492035855736447, 4.7907031643173799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.90198801393410333
    rotMatrix23.Xy = 0.11361553069085012
    rotMatrix23.Xz = -0.41654427604403738
    rotMatrix23.Yx = -0.22349873584488938
    rotMatrix23.Yy = 0.9483061161270443
    rotMatrix23.Yz = -0.22530828922119053
    rotMatrix23.Zx = 0.36941296376135896
    rotMatrix23.Zy = 0.29632249543677858
    rotMatrix23.Zz = 0.88075367776874647
    translation23 = NXOpen.Point3d(-15.899779227308471, -2.1736676532678514, -20.53784416071565)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 5.3461184690861465)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects1 = [NXOpen.DisplayableObject.Null] * 1 
    objects1[0] = datumPlane2
    theSession.DisplayManager.BlankObjects(objects1)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects2 = [NXOpen.DisplayableObject.Null] * 1 
    objects2[0] = datumPlane4
    theSession.DisplayManager.BlankObjects(objects2)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Show")
    
    objects3 = [NXOpen.DisplayableObject.Null] * 1 
    objects3[0] = datumPlane4
    theSession.DisplayManager.ShowObjects(objects3, NXOpen.DisplayManager.LayerSetting.ChangeLayerToSelectable)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.ShowOnly)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects4 = [NXOpen.DisplayableObject.Null] * 1 
    objects4[0] = datumPlane4
    theSession.DisplayManager.BlankObjects(objects4)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin33, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane21
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId190, "Create Sketch Dialog")
    
    scalar9 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point65 = workPart.Points.CreatePoint(edge6, scalar9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction12 = workPart.Directions.CreateDirection(edge6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude2.FindObject("FACE 130 {(10,7,10) EXTRUDE(3)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction12, point65, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem6
    
    origin34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin34, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane22.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom28 = [NXOpen.NXObject.Null] * 1 
    geom28[0] = face3
    plane22.SetGeometry(geom28)
    
    plane22.SetFlip(False)
    
    plane22.SetExpression(None)
    
    plane22.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane22.Evaluate()
    
    origin35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin35, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression100 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression101 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane23.SynchronizeToPlane(plane22)
    
    scalar10 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point66 = workPart.Points.CreatePoint(edge6, scalar10, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom29 = [NXOpen.NXObject.Null] * 1 
    geom29[0] = face3
    plane23.SetGeometry(geom29)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId191, None)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject32 = sketchInPlaceBuilder7.Commit()
    
    sketch7 = nXObject32
    feature16 = sketch7.Feature
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId193)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId192, None)
    
    theSession.SetUndoMarkName(markId190, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression99)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point66)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression98)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane21.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression101)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression100)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane23.DestroyPlane()
    
    scaleAboutPoint145 = NXOpen.Point3d(-7.6215732159594953, 12.17472085146775, 0.0)
    viewCenter145 = NXOpen.Point3d(7.6215732159594953, -12.174720851467775, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(-6.0972585727675952, 9.7397766811741917, 0.0)
    viewCenter146 = NXOpen.Point3d(6.0972585727675952, -9.7397766811742237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(-4.8778068582140763, 7.7918213449393532, 0.0)
    viewCenter147 = NXOpen.Point3d(4.8778068582140763, -7.7918213449393798, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-3.9022454865712617, 6.2334570759514802, 0.0)
    viewCenter148 = NXOpen.Point3d(3.9022454865712577, -6.2334570759515104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-4.8778068582140763, 7.7918213449393541, 0.0)
    viewCenter149 = NXOpen.Point3d(4.8778068582140763, -7.7918213449393843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-6.0972585727675934, 9.7397766811741953, 0.0)
    viewCenter150 = NXOpen.Point3d(6.097258572767597, -9.7397766811742255, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(-7.6215732159594962, 13.758424376861933, 0.0)
    viewCenter151 = NXOpen.Point3d(7.6215732159594962, -13.758424376861964, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(-6.0576659846327416, 11.165109854028964, 0.0)
    viewCenter152 = NXOpen.Point3d(6.0576659846327416, -11.165109854028984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-4.8144587171983106, 8.9637619537310513, 0.0)
    viewCenter153 = NXOpen.Point3d(4.8144587171983106, -8.9637619537310727, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-6.018073396497889, 11.204702442163819, 0.0)
    viewCenter154 = NXOpen.Point3d(6.018073396497889, -11.204702442163841, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint154, viewCenter154)
    
    origin36 = NXOpen.Point3d(21.902423859879757, 7.0, 13.227687799532861)
    workPart.ModelingViews.WorkView.SetOrigin(origin36)
    
    origin37 = NXOpen.Point3d(21.902423859879757, 7.0, 13.227687799532861)
    workPart.ModelingViews.WorkView.SetOrigin(origin37)
    
    scaleAboutPoint155 = NXOpen.Point3d(-9.1557860061851102, 6.8792121884309658, 0.0)
    viewCenter155 = NXOpen.Point3d(9.1557860061851102, -6.8792121884309871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint155, viewCenter155)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId195, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint13 = NXOpen.Point3d(1.7999999999999972, 7.0, 4.5)
    endPoint13 = NXOpen.Point3d(1.799999999999951, 7.0, 16.800000000000001)
    line15 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom30.Geometry = line15
    geom30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateVerticalConstraint(geom30)
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line15
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line15
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(0.45322849808996213, 7.0, 10.649999999999995)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_8, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint12
    dimension12 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression102 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId196, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint14 = NXOpen.Point3d(1.799999999999951, 7.0, 16.800000000000001)
    endPoint14 = NXOpen.Point3d(4.799999999999951, 7.0, 16.800000000000001)
    line16 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line16
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line15
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom31.Geometry = line16
    geom31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateHorizontalConstraint(geom31)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line16
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line16
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(3.299999999999951, 7.0, 18.146771501910013)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_9, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression103 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId197, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint15 = NXOpen.Point3d(4.799999999999951, 7.0, 16.800000000000001)
    endPoint15 = NXOpen.Point3d(4.799999999999951, 7.0, 14.904628304506335)
    line17 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line17
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line16
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom32.Geometry = line17
    geom32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateVerticalConstraint(geom32)
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line17
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line17
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(6.1467715019099627, 7.0, 15.852314152253168)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_10, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression104 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId198, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint16 = NXOpen.Point3d(4.799999999999951, 7.0, 14.904628304506335)
    endPoint16 = NXOpen.Point3d(17.49999999999995, 7.0, 14.904628304506335)
    line18 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line18
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line17
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom33.Geometry = line18
    geom33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreateHorizontalConstraint(geom33)
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = line18
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line18
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(11.149999999999951, 7.0, 16.251399806416348)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_15, dimObject2_11, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint15
    dimension15 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression105 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId199, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint17 = NXOpen.Point3d(17.49999999999995, 7.0, 14.904628304506335)
    endPoint17 = NXOpen.Point3d(17.499999999999954, 7.0, 12.304628304506336)
    line19 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line19
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line18
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom34.Geometry = line19
    geom34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreateVerticalConstraint(geom34)
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line19
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line19
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(18.846771501909963, 7.0, 13.604628304506337)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_12, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression106 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId200, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint18 = NXOpen.Point3d(17.499999999999954, 7.0, 12.304628304506336)
    endPoint18 = NXOpen.Point3d(15.574191925913404, 7.0, 9.7489946723549963)
    line20 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line20
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line19
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = line20
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line20
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(17.612675508301738, 7.0, 10.216304165828175)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_17, dimObject2_13, dimOrigin17, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint17
    dimension17 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression107 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    dimObject1_18 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis4 = workPart.Datums.FindObject("SKETCH(14:1B) X axis")
    dimObject1_18.Geometry = datumAxis4
    dimObject1_18.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_18.AssocValue = 0
    dimObject1_18.HelpPoint.X = 48.575000000000003
    dimObject1_18.HelpPoint.Y = 7.0
    dimObject1_18.HelpPoint.Z = 20.0
    dimObject1_18.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line20
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 15.574191925913404
    dimObject2_14.HelpPoint.Y = 7.0
    dimObject2_14.HelpPoint.Z = 9.7489946723549963
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin18 = NXOpen.Point3d(28.199210653851459, 7.0, 10.171454248387148)
    sketchDimensionalConstraint18 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_18, dimObject2_14, dimOrigin18, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension18 = sketchDimensionalConstraint18.AssociatedDimension
    
    expression108 = sketchDimensionalConstraint18.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId201, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint19 = NXOpen.Point3d(15.574191925913404, 7.0, 9.7489946723549963)
    endPoint19 = NXOpen.Point3d(14.074191925913404, 7.0, 9.7489946723549927)
    line21 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line21
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line20
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom35.Geometry = line21
    geom35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateHorizontalConstraint(geom35)
    
    dimObject1_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_19.Geometry = line21
    dimObject1_19.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_19.AssocValue = 0
    dimObject1_19.HelpPoint.X = 0.0
    dimObject1_19.HelpPoint.Y = 0.0
    dimObject1_19.HelpPoint.Z = 0.0
    dimObject1_19.View = NXOpen.NXObject.Null
    dimObject2_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_15.Geometry = line21
    dimObject2_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_15.AssocValue = 0
    dimObject2_15.HelpPoint.X = 0.0
    dimObject2_15.HelpPoint.Y = 0.0
    dimObject2_15.HelpPoint.Z = 0.0
    dimObject2_15.View = NXOpen.NXObject.Null
    dimOrigin19 = NXOpen.Point3d(14.824191925913407, 7.0, 8.4022231704449819)
    sketchDimensionalConstraint19 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_19, dimObject2_15, dimOrigin19, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint15 = sketchDimensionalConstraint19
    dimension19 = sketchHelpedDimensionalConstraint15.AssociatedDimension
    
    expression109 = sketchHelpedDimensionalConstraint15.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId202, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint20 = NXOpen.Point3d(14.074191925913404, 7.0, 9.7489946723549927)
    endPoint20 = NXOpen.Point3d(15.999999999999945, 7.0, 12.304628304506336)
    line22 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line22
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line21
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line22
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line20
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateParallelConstraint(conGeom1_11, conGeom2_11)
    
    dimObject1_20 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_20.Geometry = line22
    dimObject1_20.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_20.AssocValue = 0
    dimObject1_20.HelpPoint.X = 0.0
    dimObject1_20.HelpPoint.Y = 0.0
    dimObject1_20.HelpPoint.Z = 0.0
    dimObject1_20.View = NXOpen.NXObject.Null
    dimObject2_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_16.Geometry = line22
    dimObject2_16.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_16.AssocValue = 0
    dimObject2_16.HelpPoint.X = 0.0
    dimObject2_16.HelpPoint.Y = 0.0
    dimObject2_16.HelpPoint.Z = 0.0
    dimObject2_16.View = NXOpen.NXObject.Null
    dimOrigin20 = NXOpen.Point3d(13.961516417611609, 7.0, 11.837318811033152)
    sketchDimensionalConstraint20 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_20, dimObject2_16, dimOrigin20, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint16 = sketchDimensionalConstraint20
    dimension20 = sketchHelpedDimensionalConstraint16.AssociatedDimension
    
    expression110 = sketchHelpedDimensionalConstraint16.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId203, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint21 = NXOpen.Point3d(15.999999999999945, 7.0, 12.304628304506336)
    endPoint21 = NXOpen.Point3d(4.799999999999951, 7.0, 12.304628304506336)
    line23 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line23
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line22
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom36 = NXOpen.Sketch.ConstraintGeometry()
    
    geom36.Geometry = line23
    geom36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreateHorizontalConstraint(geom36)
    
    dimObject1_21 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_21.Geometry = line23
    dimObject1_21.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_21.AssocValue = 0
    dimObject1_21.HelpPoint.X = 0.0
    dimObject1_21.HelpPoint.Y = 0.0
    dimObject1_21.HelpPoint.Z = 0.0
    dimObject1_21.View = NXOpen.NXObject.Null
    dimObject2_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_17.Geometry = line23
    dimObject2_17.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_17.AssocValue = 0
    dimObject2_17.HelpPoint.X = 0.0
    dimObject2_17.HelpPoint.Y = 0.0
    dimObject2_17.HelpPoint.Z = 0.0
    dimObject2_17.View = NXOpen.NXObject.Null
    dimOrigin21 = NXOpen.Point3d(10.399999999999949, 7.0, 10.957856802596323)
    sketchDimensionalConstraint21 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_21, dimObject2_17, dimOrigin21, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint17 = sketchDimensionalConstraint21
    dimension21 = sketchHelpedDimensionalConstraint17.AssociatedDimension
    
    expression111 = sketchHelpedDimensionalConstraint17.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId204, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint22 = NXOpen.Point3d(4.799999999999951, 7.0, 12.304628304506336)
    endPoint22 = NXOpen.Point3d(4.799999999999951, 7.0, 4.5)
    line24 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line24
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line23
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom37 = NXOpen.Sketch.ConstraintGeometry()
    
    geom37.Geometry = line24
    geom37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreateVerticalConstraint(geom37)
    
    dimObject1_22 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_22.Geometry = line24
    dimObject1_22.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_22.AssocValue = 0
    dimObject1_22.HelpPoint.X = 0.0
    dimObject1_22.HelpPoint.Y = 0.0
    dimObject1_22.HelpPoint.Z = 0.0
    dimObject1_22.View = NXOpen.NXObject.Null
    dimObject2_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_18.Geometry = line24
    dimObject2_18.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_18.AssocValue = 0
    dimObject2_18.HelpPoint.X = 0.0
    dimObject2_18.HelpPoint.Y = 0.0
    dimObject2_18.HelpPoint.Z = 0.0
    dimObject2_18.View = NXOpen.NXObject.Null
    dimOrigin22 = NXOpen.Point3d(6.1467715019099627, 7.0, 8.4023141522531688)
    sketchDimensionalConstraint22 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_22, dimObject2_18, dimOrigin22, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint18 = sketchDimensionalConstraint22
    dimension22 = sketchHelpedDimensionalConstraint18.AssociatedDimension
    
    expression112 = sketchHelpedDimensionalConstraint18.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId205, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint23 = NXOpen.Point3d(1.7999999999999972, 7.0, 4.5)
    endPoint23 = NXOpen.Point3d(4.799999999999951, 7.0, 4.5)
    line25 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line25
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_26.Geometry = line15
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom38 = NXOpen.Sketch.ConstraintGeometry()
    
    geom38.Geometry = line25
    geom38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom38.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateHorizontalConstraint(geom38)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line25
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = line24
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    theSession.SetUndoMarkName(markId206, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point67 = NXOpen.Point3d(5.2240461080722902, 7.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(edge2, workPart.ModelingViews.WorkView, point67)
    
    point1_50 = NXOpen.Point3d(1.7999999999999972, 7.0, 4.5)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point68 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point68
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point69 = NXOpen.Point3d(-3.4863232815957055, 7.0, 1.7557353874587633)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point69)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject33 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId207, None)
    
    theSession.SetUndoMarkName(markId206, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId208, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression113 = workPart.Expressions.FindObject("p37")
    expression113.SetFormula("5")
    
    theSession.SetUndoMarkVisibility(markId208, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId209, None)
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId208, "Edit Driving Value")
    
    point70 = NXOpen.Point3d(1.7999999999999972, 7.0, 9.397104897485681)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(line15, workPart.ModelingViews.WorkView, point70)
    
    point1_51 = NXOpen.Point3d(1.7999999999999972, 7.0, 5.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(1.7999999999999972, 7.0, 17.300000000000001)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point71 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point71
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point72 = NXOpen.Point3d(-4.3177676324276497, 7.0, 9.6346604262948077)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point72)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject34 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId211, None)
    
    theSession.SetUndoMarkName(markId210, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId210, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId212, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression114 = workPart.Expressions.FindObject("p38")
    expression114.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId212, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId213, None)
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId212, "Edit Driving Value")
    
    point73 = NXOpen.Point3d(4.1154536402963622, 7.0, 15.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(line16, workPart.ModelingViews.WorkView, point73)
    
    point1_53 = NXOpen.Point3d(4.7999999999999972, 7.0, 15.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(1.7999999999999972, 7.0, 15.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line16, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    point1_55 = NXOpen.Point3d(0.0, 7.0, 20.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge6, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(4.1154536402963622, 7.0, 15.0)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(0.0, 7.0, 20.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge6, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(4.1154536402963622, 7.0, 15.0)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(0.0, 7.0, 20.0)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge6, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point74 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point74
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point75 = NXOpen.Point3d(-3.3279529290562877, 7.0, 19.49321487187358)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point75)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = False
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject35 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId215, None)
    
    theSession.SetUndoMarkName(markId214, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId214, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId216, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId216, None)
    
    theSession.DeleteUndoMark(markId216, None)
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension4 = nXObject35
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension4)
    
    sketchLinearDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId217, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits645 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder7.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits647 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits651 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchLinearDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId218, None)
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    expression115 = sketchLinearDimensionBuilder7.Driving.ExpressionValue
    sketchLinearDimensionBuilder7.Destroy()
    
    theSession.UndoToMark(markId217, None)
    
    theSession.DeleteUndoMark(markId217, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects5 = [NXOpen.TaggedObject.Null] * 1 
    objects5[0] = perpendicularDimension4
    nErrs11 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs12 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId220, None)
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension5 = nXObject33
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension5)
    
    sketchLinearDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId222, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits663 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits665 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits669 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits679 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId223, None)
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point76 = workPart.Points.FindObject("ENTITY 2 26")
    assocOrigin14.PointOnGeometry = point76
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point77 = NXOpen.Point3d(-3.2883603409214217, 7.0, 1.99329091626789)
    sketchLinearDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point77)
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits681 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits687 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits689 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchLinearDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId224, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId224, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId222, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder8.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    nXObject36 = sketchLinearDimensionBuilder8.Commit()
    
    taggedObject3 = sketchLinearDimensionBuilder8.FirstAssociativity.Value
    
    line26 = taggedObject3
    point1_60 = NXOpen.Point3d(5.2240461080722902, 7.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, NXOpen.View.Null, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    point1_61 = NXOpen.Point3d(1.7999999999999972, 7.0, 3.0)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, NXOpen.View.Null, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    sketchLinearDimensionBuilder8.Driving.ExpressionValue.SetFormula("3")
    
    theSession.SetUndoMarkName(markId225, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId225, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId222, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject37 = sketchLinearDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId227, None)
    
    theSession.SetUndoMarkName(markId222, "Linear Dimension")
    
    expression116 = sketchLinearDimensionBuilder8.Driving.ExpressionValue
    sketchLinearDimensionBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId226, None)
    
    theSession.SetUndoMarkVisibility(markId222, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId225, None)
    
    theSession.DeleteUndoMark(markId224, None)
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    verticalDimension1 = nXObject34
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(verticalDimension1)
    
    sketchLinearDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId228, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits693 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder9.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits695 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits699 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits705 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits709 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchLinearDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId229, None)
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder9.Driving.ExpressionValue.SetFormula("14")
    
    sketchLinearDimensionBuilder9.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    nXObject38 = sketchLinearDimensionBuilder9.Commit()
    
    point1_62 = NXOpen.Point3d(1.7999999999999972, 7.0, 3.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, NXOpen.View.Null, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(1.7999999999999972, 7.0, 17.0)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, NXOpen.View.Null, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    sketchLinearDimensionBuilder9.Driving.ExpressionValue.SetFormula("14")
    
    theSession.SetUndoMarkName(markId230, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId230, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId228, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject39 = sketchLinearDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId232, None)
    
    theSession.SetUndoMarkName(markId228, "Linear Dimension")
    
    expression117 = sketchLinearDimensionBuilder9.Driving.ExpressionValue
    sketchLinearDimensionBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId231, None)
    
    theSession.SetUndoMarkVisibility(markId228, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId230, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines89 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines92)
    
    theSession.SetUndoMarkName(markId233, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder17.Destroy()
    
    theSession.UndoToMark(markId233, None)
    
    theSession.DeleteUndoMark(markId233, None)
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines97 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines100)
    
    theSession.SetUndoMarkName(markId234, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    point78 = NXOpen.Point3d(7.5204162198938587, 7.0, 10.804628304506338)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(line23, workPart.ModelingViews.WorkView, point78)
    
    point1_64 = NXOpen.Point3d(4.8000000000000007, 7.0, 10.804628304506338)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(15.999999999999995, 7.0, 10.804628304506334)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    point1_66 = NXOpen.Point3d(4.7999999999999972, 7.0, 13.404628304506335)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(7.5204162198938587, 7.0, 10.804628304506338)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    point1_68 = NXOpen.Point3d(4.7999999999999972, 7.0, 13.404628304506335)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(7.5204162198938587, 7.0, 10.804628304506338)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(4.7999999999999972, 7.0, 13.404628304506335)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point79 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point79
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point80 = NXOpen.Point3d(26.287302995814894, 7.0, 12.683289712678606)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point80)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject40 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId235, None)
    
    theSession.SetUndoMarkName(markId234, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId236, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression118 = workPart.Expressions.FindObject("p39")
    expression118.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId236, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId237, None)
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId236, "Edit Driving Value")
    
    point81 = NXOpen.Point3d(4.7093424623191904, 7.0, 3.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(line25, workPart.ModelingViews.WorkView, point81)
    
    point1_71 = NXOpen.Point3d(5.2521324300616783, 7.0, 3.0)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line25, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(1.7999999999999972, 7.0, 3.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    point1_73 = NXOpen.Point3d(10.852132430061676, 7.0, 10.804628304506334)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line23, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(4.7093424623191904, 7.0, 3.0)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(10.852132430061676, 7.0, 10.804628304506334)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line23, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(4.7093424623191904, 7.0, 3.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    point1_77 = NXOpen.Point3d(10.852132430061676, 7.0, 10.804628304506334)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line23, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point82 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point82
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder19.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point83 = NXOpen.Point3d(8.5102309232652225, 7.0, 7.0215496093944116)
    sketchRapidDimensionBuilder19.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point83)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.TextCentered = True
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject41 = sketchRapidDimensionBuilder19.Commit()
    
    theSession.DeleteUndoMark(markId239, None)
    
    theSession.SetUndoMarkName(markId238, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId238, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines105 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines108)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId240, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    expression119 = workPart.Expressions.FindObject("p40")
    expression119.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId240, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId241, None)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId240, "Edit Driving Value")
    
    sketchRapidDimensionBuilder20.Destroy()
    
    theSession.UndoToMark(markId242, None)
    
    theSession.DeleteUndoMark(markId242, None)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal20 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin38, normal20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane24
    
    expression120 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression121 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId243, "Create Sketch Dialog")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression121)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression120)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane24.DestroyPlane()
    
    theSession.UndoToMark(markId243, None)
    
    theSession.DeleteUndoMark(markId243, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines113 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId244, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits833 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits834 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits835 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits836 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits837 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits838 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits839 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits840 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits841 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits842 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits843 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits844 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits845 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits846 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    point84 = NXOpen.Point3d(4.2738239928357906, 7.0, 3.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(line25, workPart.ModelingViews.WorkView, point84)
    
    point1_78 = NXOpen.Point3d(5.2521324300616783, 7.0, 3.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line25, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    point1_79 = NXOpen.Point3d(1.7999999999999972, 7.0, 3.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    dimensionlinearunits847 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits848 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits849 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits850 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits851 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits852 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point85 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point85
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point86 = NXOpen.Point3d(7.2036755148150231, 7.0, -2.0451530734872687)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point86)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = False
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject42 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId245, None)
    
    theSession.SetUndoMarkName(markId244, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId244, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId246, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits853 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits854 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits855 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits856 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits857 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits858 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits859 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits860 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits861 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits862 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits863 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits864 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits865 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits866 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits867 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits868 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits869 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits870 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits871 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits872 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    expression122 = workPart.Expressions.FindObject("p41")
    expression122.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId246, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId247, None)
    
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId246, "Edit Driving Value")
    
    point87 = NXOpen.Point3d(3.7987129352175373, 7.0, 17.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(line16, workPart.ModelingViews.WorkView, point87)
    
    point1_80 = NXOpen.Point3d(4.347867569938316, 7.0, 17.0)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line16, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(1.7999999999999972, 7.0, 17.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line16, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    dimensionlinearunits873 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits874 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits875 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits876 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits877 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits878 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point88 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point88
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder22.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point89 = NXOpen.Point3d(5.3824164606117151, 7.0, 23.650436626033301)
    sketchRapidDimensionBuilder22.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point89)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.TextCentered = False
    
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject43 = sketchRapidDimensionBuilder22.Commit()
    
    theSession.DeleteUndoMark(markId249, None)
    
    theSession.SetUndoMarkName(markId248, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId248, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId250, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits879 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits880 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits881 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits882 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits883 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits884 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits885 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits886 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits887 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits888 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits889 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits890 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits891 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits892 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits893 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits894 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits895 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits896 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits897 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits898 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    expression123 = workPart.Expressions.FindObject("p42")
    expression123.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId250, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId251, None)
    
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId250, "Edit Driving Value")
    
    scaleAboutPoint156 = NXOpen.Point3d(-3.9988514016203038, 2.9298515219792236, 0.0)
    viewCenter156 = NXOpen.Point3d(3.9988514016203038, -2.929851521979244, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(-3.199081121296246, 2.3438812175833763, 0.0)
    viewCenter157 = NXOpen.Point3d(3.1990811212962402, -2.3438812175833981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint157, viewCenter157)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    theSession.UndoToMark(markId252, None)
    
    theSession.DeleteUndoMark(markId252, None)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines125 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines128)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines129 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines132)
    
    theSession.SetUndoMarkName(markId253, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits899 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits900 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits901 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits902 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits903 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits904 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits905 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits906 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits907 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits908 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits909 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits910 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits911 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits912 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits913 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits914 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits915 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits916 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits917 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits918 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    point90 = NXOpen.Point3d(17.499999999999993, 7.0, 10.518366993464765)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(line19, workPart.ModelingViews.WorkView, point90)
    
    point1_82 = NXOpen.Point3d(17.499999999999993, 7.0, 11.000000000000002)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    point1_83 = NXOpen.Point3d(17.499999999999993, 7.0, 8.4000000000000021)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line19, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    dimensionlinearunits919 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits920 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits921 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits922 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits923 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits924 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point91 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point91
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point92 = NXOpen.Point3d(22.888675230318977, 7.0, 8.0857983784593053)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point92)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = False
    
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject44 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId254, None)
    
    theSession.SetUndoMarkName(markId253, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId253, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId255 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId255, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits925 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits926 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits927 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits928 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits929 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits930 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits931 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits932 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits933 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits934 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits935 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits936 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits937 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits938 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits939 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits940 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits941 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits942 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits943 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits944 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression124 = workPart.Expressions.FindObject("p43")
    expression124.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId255, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId256 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId256, None)
    
    markId257 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId255, "Edit Driving Value")
    
    sketchRapidDimensionBuilder25.Destroy()
    
    theSession.UndoToMark(markId257, None)
    
    theSession.DeleteUndoMark(markId257, None)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    markId258 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId259 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId259, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    parallelDimension5 = theSession.ActiveSketch.FindObject("ENTITY 26 8 1")
    theSession.UpdateManager.LogForUpdate(parallelDimension5)
    
    minorAngularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    theSession.UpdateManager.LogForUpdate(minorAngularDimension1)
    
    parallelDimension6 = theSession.ActiveSketch.FindObject("ENTITY 26 4 1")
    theSession.UpdateManager.LogForUpdate(parallelDimension6)
    
    startPoint24 = NXOpen.Point3d(4.7999999999999989, 7.0, 11.000000000000004)
    endPoint24 = NXOpen.Point3d(19.366518589842318, 7.0, 11.000000000000004)
    line18.SetEndpoints(startPoint24, endPoint24)
    
    startPoint25 = NXOpen.Point3d(19.366518589842318, 7.0, 9.0000000000000018)
    endPoint25 = NXOpen.Point3d(17.440710515755768, 7.0, 6.4443663678486711)
    line20.SetEndpoints(startPoint25, endPoint25)
    
    startPoint26 = NXOpen.Point3d(17.440710515755768, 7.0, 6.4443663678486711)
    endPoint26 = NXOpen.Point3d(14.074191925913443, 7.0, 6.4443663678486711)
    line21.SetEndpoints(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(19.366518589842318, 7.0, 11.000000000000004)
    endPoint27 = NXOpen.Point3d(19.366518589842318, 7.0, 9.0000000000000018)
    line19.SetEndpoints(startPoint27, endPoint27)
    
    sketchHelpedDimensionalConstraint19 = theSession.ActiveSketch.FindObject("DimensionalConstraint p39")
    sketchHelpedDimensionalConstraint19.Refresh()
    
    nErrs13 = theSession.UpdateManager.DoUpdate(markId259)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line18
    geoms6[1] = line20
    geoms6[2] = line21
    geoms6[3] = line19
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms6)
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line18
    geoms7[1] = line20
    geoms7[2] = line21
    geoms7[3] = line19
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line18
    geoms8[1] = line20
    geoms8[2] = line21
    geoms8[3] = line19
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    markId260 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId261 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId261, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(minorAngularDimension1)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension5)
    
    perpendicularDimension6 = theSession.ActiveSketch.FindObject("ENTITY 26 12 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension6)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension6)
    
    parallelDimension7 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    theSession.UpdateManager.LogForUpdate(parallelDimension7)
    
    startPoint28 = NXOpen.Point3d(0.68867523031898159, 7.0, 3.0000000000000071)
    endPoint28 = NXOpen.Point3d(3.6886752303189816, 7.0, 3.0)
    line25.SetEndpoints(startPoint28, endPoint28)
    
    startPoint29 = NXOpen.Point3d(3.6886752303189816, 7.0, 11.000000000000004)
    endPoint29 = NXOpen.Point3d(19.366518589842318, 7.0, 11.000000000000004)
    line18.SetEndpoints(startPoint29, endPoint29)
    
    startPoint30 = NXOpen.Point3d(19.366518589842318, 7.0, 9.0000000000000018)
    endPoint30 = NXOpen.Point3d(16.329385746074752, 7.0, 6.4443663678486711)
    line20.SetEndpoints(startPoint30, endPoint30)
    
    startPoint31 = NXOpen.Point3d(17.111324769681008, 7.0, 9.0000000000000018)
    endPoint31 = NXOpen.Point3d(3.6886752303189816, 7.0, 9.0000000000000071)
    line23.SetEndpoints(startPoint31, endPoint31)
    
    startPoint32 = NXOpen.Point3d(16.329385746074752, 7.0, 6.4443663678486711)
    endPoint32 = NXOpen.Point3d(14.074191925913443, 7.0, 6.4443663678486711)
    line21.SetEndpoints(startPoint32, endPoint32)
    
    startPoint33 = NXOpen.Point3d(0.68867523031898159, 7.0, 17.0)
    endPoint33 = NXOpen.Point3d(3.6886752303189816, 7.0, 17.0)
    line16.SetEndpoints(startPoint33, endPoint33)
    
    startPoint34 = NXOpen.Point3d(0.68867523031898159, 7.0, 3.0000000000000071)
    endPoint34 = NXOpen.Point3d(0.68867523031898159, 7.0, 17.0)
    line15.SetEndpoints(startPoint34, endPoint34)
    
    startPoint35 = NXOpen.Point3d(14.074191925913443, 7.0, 6.4443663678486711)
    endPoint35 = NXOpen.Point3d(17.111324769681008, 7.0, 9.0000000000000018)
    line22.SetEndpoints(startPoint35, endPoint35)
    
    startPoint36 = NXOpen.Point3d(3.6886752303189816, 7.0, 17.0)
    endPoint36 = NXOpen.Point3d(3.6886752303189816, 7.0, 11.000000000000004)
    line17.SetEndpoints(startPoint36, endPoint36)
    
    startPoint37 = NXOpen.Point3d(3.6886752303189816, 7.0, 9.0000000000000071)
    endPoint37 = NXOpen.Point3d(3.6886752303189816, 7.0, 3.0)
    line24.SetEndpoints(startPoint37, endPoint37)
    
    sketchHelpedDimensionalConstraint20 = theSession.ActiveSketch.FindObject("DimensionalConstraint p37")
    sketchHelpedDimensionalConstraint20.Refresh()
    
    sketchHelpedDimensionalConstraint21 = theSession.ActiveSketch.FindObject("DimensionalConstraint p40")
    sketchHelpedDimensionalConstraint21.Refresh()
    
    sketchHelpedDimensionalConstraint22 = theSession.ActiveSketch.FindObject("ENTITY 243 59 1")
    sketchHelpedDimensionalConstraint22.Refresh()
    
    sketchHelpedDimensionalConstraint19.Refresh()
    
    nErrs14 = theSession.UpdateManager.DoUpdate(markId261)
    
    geoms9 = [NXOpen.SmartObject.Null] * 10 
    geoms9[0] = line25
    geoms9[1] = line18
    geoms9[2] = line20
    geoms9[3] = line24
    geoms9[4] = line23
    geoms9[5] = line21
    geoms9[6] = line15
    geoms9[7] = line22
    geoms9[8] = line16
    geoms9[9] = line17
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 10 
    geoms10[0] = line25
    geoms10[1] = line18
    geoms10[2] = line20
    geoms10[3] = line24
    geoms10[4] = line23
    geoms10[5] = line21
    geoms10[6] = line15
    geoms10[7] = line22
    geoms10[8] = line16
    geoms10[9] = line17
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms10)
    
    geoms11 = [NXOpen.SmartObject.Null] * 10 
    geoms11[0] = line25
    geoms11[1] = line18
    geoms11[2] = line20
    geoms11[3] = line24
    geoms11[4] = line23
    geoms11[5] = line21
    geoms11[6] = line15
    geoms11[7] = line22
    geoms11[8] = line16
    geoms11[9] = line17
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms11)
    
    scaleAboutPoint158 = NXOpen.Point3d(-10.97189802393088, 3.3194425892261865, 0.0)
    viewCenter158 = NXOpen.Point3d(10.97189802393088, -3.3194425892262149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(-13.683198459405716, 4.1176291660248561, 0.0)
    viewCenter159 = NXOpen.Point3d(13.683198459405716, -4.1176291660248827, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(-29.813218865545441, 4.6323328117779603, 0.0)
    viewCenter160 = NXOpen.Point3d(29.813218865545441, -4.6323328117779905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    markId262 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    verticalDimension2 = nXObject39
    sketchLinearDimensionBuilder10 = workPart.Sketches.CreateLinearDimensionBuilder(verticalDimension2)
    
    sketchLinearDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId262, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits945 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits946 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder10.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits947 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits948 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits949 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits950 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits951 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits952 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits953 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits954 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits955 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits956 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits957 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits958 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits959 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits960 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits961 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits962 = sketchLinearDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId263 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId263, None)
    
    markId264 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder10.Driving.ExpressionValue.SetFormula("10")
    
    sketchLinearDimensionBuilder10.Driving.ExpressionValue.SetFormula("10")
    
    sketchLinearDimensionBuilder10.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    nXObject45 = sketchLinearDimensionBuilder10.Commit()
    
    point1_84 = NXOpen.Point3d(0.68867523031898159, 7.0, 3.0000000000000071)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, NXOpen.View.Null, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(0.68867523031898514, 7.0, 13.000000000000007)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, NXOpen.View.Null, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    theSession.SetUndoMarkName(markId264, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId264, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId262, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId265 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId266 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject46 = sketchLinearDimensionBuilder10.Commit()
    
    theSession.DeleteUndoMark(markId266, None)
    
    theSession.SetUndoMarkName(markId262, "Linear Dimension")
    
    expression125 = sketchLinearDimensionBuilder10.Driving.ExpressionValue
    sketchLinearDimensionBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId265, None)
    
    theSession.SetUndoMarkVisibility(markId262, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId264, None)
    
    markId267 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension7 = nXObject37
    sketchLinearDimensionBuilder11 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension7)
    
    sketchLinearDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId267, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits963 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits964 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder11.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits965 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits966 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits967 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits968 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits969 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits970 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits971 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits972 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits973 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits974 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits975 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits976 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits977 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits978 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits979 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits980 = sketchLinearDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId268 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId268, None)
    
    markId269 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder11.Driving.ExpressionValue.SetFormula("5")
    
    sketchLinearDimensionBuilder11.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    nXObject47 = sketchLinearDimensionBuilder11.Commit()
    
    point1_86 = NXOpen.Point3d(5.2240461080722902, 7.0, 0.0)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, NXOpen.View.Null, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    point1_87 = NXOpen.Point3d(0.68867523031898159, 7.0, 5.0)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, NXOpen.View.Null, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    sketchLinearDimensionBuilder11.Driving.ExpressionValue.SetFormula("5")
    
    theSession.SetUndoMarkName(markId269, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId269, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId267, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId270 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId271 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject48 = sketchLinearDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId271, None)
    
    theSession.SetUndoMarkName(markId267, "Linear Dimension")
    
    expression126 = sketchLinearDimensionBuilder11.Driving.ExpressionValue
    sketchLinearDimensionBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId270, None)
    
    theSession.SetUndoMarkVisibility(markId267, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId269, None)
    
    markId272 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension8 = nXObject41
    sketchLinearDimensionBuilder12 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension8)
    
    sketchLinearDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId272, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits981 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits982 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder12.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits983 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits984 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits985 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits986 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits987 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits988 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits989 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits990 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits991 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits992 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits993 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits994 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits995 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits996 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits997 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits998 = sketchLinearDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId273 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId273, None)
    
    markId274 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder12.Driving.ExpressionValue.SetFormula("2")
    
    sketchLinearDimensionBuilder12.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    nXObject49 = sketchLinearDimensionBuilder12.Commit()
    
    point1_88 = NXOpen.Point3d(3.2169755095761219, 7.0, 5.0)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, NXOpen.View.Null, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    point1_89 = NXOpen.Point3d(10.399999999999995, 7.0, 6.9999999999999973)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line23, NXOpen.View.Null, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    sketchLinearDimensionBuilder12.Driving.ExpressionValue.SetFormula("2")
    
    theSession.SetUndoMarkName(markId274, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId274, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId272, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId275 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId276 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject50 = sketchLinearDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId276, None)
    
    theSession.SetUndoMarkName(markId272, "Linear Dimension")
    
    expression127 = sketchLinearDimensionBuilder12.Driving.ExpressionValue
    sketchLinearDimensionBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId275, None)
    
    theSession.SetUndoMarkVisibility(markId272, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId274, None)
    
    markId277 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder13 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension6)
    
    sketchLinearDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId277, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits999 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1000 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder13.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits1001 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1002 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1003 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1004 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1005 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1006 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1007 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1008 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1009 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1010 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1011 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1012 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1013 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1014 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1015 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1016 = sketchLinearDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId278 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId278, None)
    
    markId279 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    expression128 = sketchLinearDimensionBuilder13.Driving.ExpressionValue
    sketchLinearDimensionBuilder13.Destroy()
    
    theSession.UndoToMark(markId277, None)
    
    theSession.DeleteUndoMark(markId277, None)
    
    markId280 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension9 = nXObject50
    sketchLinearDimensionBuilder14 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension9)
    
    sketchLinearDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId280, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1017 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1018 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder14.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits1019 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1020 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1021 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1022 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1023 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1024 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1025 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1026 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1027 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1028 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1029 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1030 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1031 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1032 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1033 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1034 = sketchLinearDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId281 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId281, None)
    
    markId282 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    expression129 = sketchLinearDimensionBuilder14.Driving.ExpressionValue
    sketchLinearDimensionBuilder14.Destroy()
    
    theSession.UndoToMark(markId280, None)
    
    theSession.DeleteUndoMark(markId280, None)
    
    markId283 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder15 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension7)
    
    sketchLinearDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId283, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1035 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1036 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder15.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits1037 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1038 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1039 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1040 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1041 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1042 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1043 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1044 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1045 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1046 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1047 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1048 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1049 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1050 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1051 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1052 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId284 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId284, None)
    
    markId285 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder15.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder15.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    nXObject51 = sketchLinearDimensionBuilder15.Commit()
    
    point1_90 = NXOpen.Point3d(7.6886752303189816, 7.0, 6.9999999999999964)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, NXOpen.View.Null, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(3.6886752303189816, 7.0, 7.0)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line23, NXOpen.View.Null, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    sketchLinearDimensionBuilder15.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId285, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId285, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId283, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId286 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    theSession.SetUndoMarkVisibility(markId283, None, NXOpen.Session.MarkVisibility.Visible)
    
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    markId287 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    dimensionlinearunits1053 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1054 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1055 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1056 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1057 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1058 = sketchLinearDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.DeleteUndoMark(markId287, None)
    
    markId288 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId288, None)
    
    markId289 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    expression130 = sketchLinearDimensionBuilder15.Driving.ExpressionValue
    sketchLinearDimensionBuilder15.Destroy()
    
    theSession.UndoToMark(markId283, None)
    
    theSession.DeleteUndoMark(markId283, None)
    
    markId290 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder16 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension9)
    
    sketchLinearDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId290, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1059 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1060 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder16.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits1061 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1062 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1063 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1064 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1065 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1066 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1067 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1068 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1069 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1070 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1071 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1072 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1073 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1074 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1075 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1076 = sketchLinearDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    markId291 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId291, None)
    
    markId292 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder16.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder16.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    nXObject52 = sketchLinearDimensionBuilder16.Commit()
    
    point1_92 = NXOpen.Point3d(3.2169755095761219, 7.0, 5.0)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, NXOpen.View.Null, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    point1_93 = NXOpen.Point3d(10.399999999999995, 7.0, 8.9999999999999964)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line23, NXOpen.View.Null, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    sketchLinearDimensionBuilder16.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId292, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId292, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId290, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId293 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId294 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject53 = sketchLinearDimensionBuilder16.Commit()
    
    theSession.DeleteUndoMark(markId294, None)
    
    theSession.SetUndoMarkName(markId290, "Linear Dimension")
    
    expression131 = sketchLinearDimensionBuilder16.Driving.ExpressionValue
    sketchLinearDimensionBuilder16.Destroy()
    
    theSession.DeleteUndoMark(markId293, None)
    
    theSession.SetUndoMarkVisibility(markId290, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId292, None)
    
    scaleAboutPoint161 = NXOpen.Point3d(-16.925831427650305, 6.1863418960710055, 0.0)
    viewCenter161 = NXOpen.Point3d(16.925831427650305, -6.1863418960710312, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    markId295 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId296 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId296, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(minorAngularDimension1)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension5)
    
    startPoint38 = NXOpen.Point3d(14.572252092592784, 7.0, 6.3215526511701867)
    endPoint38 = NXOpen.Point3d(17.111324769681008, 7.0, 8.9999999999999947)
    line22.SetEndpoints(startPoint38, endPoint38)
    
    startPoint39 = NXOpen.Point3d(19.366518589842322, 7.0, 9.0)
    endPoint39 = NXOpen.Point3d(16.827445912754094, 7.0, 6.3215526511701867)
    line20.SetEndpoints(startPoint39, endPoint39)
    
    startPoint40 = NXOpen.Point3d(16.827445912754094, 7.0, 6.3215526511701867)
    endPoint40 = NXOpen.Point3d(14.572252092592784, 7.0, 6.3215526511701867)
    line21.SetEndpoints(startPoint40, endPoint40)
    
    nErrs15 = theSession.UpdateManager.DoUpdate(markId296)
    
    geoms12 = [NXOpen.SmartObject.Null] * 3 
    geoms12[0] = line22
    geoms12[1] = line20
    geoms12[2] = line21
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms12)
    
    geoms13 = [NXOpen.SmartObject.Null] * 3 
    geoms13[0] = line22
    geoms13[1] = line20
    geoms13[2] = line21
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 3 
    geoms14[0] = line22
    geoms14[1] = line20
    geoms14[2] = line21
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms14)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId297 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines137 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines140)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines141 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines141)
    
    lines142 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines142)
    
    lines143 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines143)
    
    lines144 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines144)
    
    theSession.SetUndoMarkName(markId297, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1077 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1078 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1079 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1080 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1081 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1082 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1083 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1084 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1085 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1086 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1087 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1088 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1089 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1090 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1091 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1092 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1093 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1094 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1095 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1096 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    point1_94 = NXOpen.Point3d(16.827445912754094, 7.0, 6.3215526511701867)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    scaleAboutPoint162 = NXOpen.Point3d(-13.342702201445974, 7.6413695100269061, 0.0)
    viewCenter162 = NXOpen.Point3d(13.34270220144597, -7.6413695100269372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(-10.674161761156777, 6.1130956080215242, 0.0)
    viewCenter163 = NXOpen.Point3d(10.674161761156777, -6.1130956080215508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(-8.1339013064245123, 4.7891194607919871, 0.0)
    viewCenter164 = NXOpen.Point3d(8.1339013064245123, -4.7891194607920156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    theSession.UndoToMark(markId297, None)
    
    theSession.DeleteUndoMark(markId297, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId298 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder27 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines145 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines145)
    
    lines146 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines146)
    
    lines147 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines147)
    
    lines148 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines148)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder27.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines149 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines149)
    
    lines150 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines150)
    
    lines151 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines151)
    
    lines152 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines152)
    
    theSession.SetUndoMarkName(markId298, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder27.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1097 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1098 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1099 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1100 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1101 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1102 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1103 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1104 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1105 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1106 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder27.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1107 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1108 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1109 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1110 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1111 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1112 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1113 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1114 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1115 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1116 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder27.Destroy()
    
    theSession.UndoToMark(markId298, None)
    
    theSession.DeleteUndoMark(markId298, None)
    
    markId299 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder28 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines153 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines153)
    
    lines154 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines154)
    
    lines155 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines155)
    
    lines156 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines156)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder28.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines157 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines157)
    
    lines158 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines158)
    
    lines159 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines159)
    
    lines160 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines160)
    
    theSession.SetUndoMarkName(markId299, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder28.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1117 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1118 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1119 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1120 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1121 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1122 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1123 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1124 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1125 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1126 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder28.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1127 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1128 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1129 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1130 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1131 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1132 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1133 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1134 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1135 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1136 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    point93 = NXOpen.Point3d(16.352018114430756, 7.0, 6.3215526511701867)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(line21, workPart.ModelingViews.WorkView, point93)
    
    point1_95 = NXOpen.Point3d(16.827445912754094, 7.0, 6.3215526511701867)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    point1_96 = NXOpen.Point3d(14.572252092592784, 7.0, 6.3215526511701867)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line21, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    dimensionlinearunits1137 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1138 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1139 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1140 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1141 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1142 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point94 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point94
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder28.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point95 = NXOpen.Point3d(15.987132822179934, 7.0, 4.7330980151998201)
    sketchRapidDimensionBuilder28.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point95)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.TextCentered = False
    
    markId300 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject54 = sketchRapidDimensionBuilder28.Commit()
    
    theSession.DeleteUndoMark(markId300, None)
    
    theSession.SetUndoMarkName(markId299, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId299, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder28.Destroy()
    
    markId301 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder29 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines161 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines161)
    
    lines162 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines162)
    
    lines163 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines163)
    
    lines164 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines164)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder29.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId301, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder29.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1143 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1144 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1145 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1146 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1147 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1148 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1149 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1150 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1151 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1152 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder29.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1153 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1154 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1155 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1156 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1157 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1158 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1159 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1160 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1161 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1162 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    expression132 = workPart.Expressions.FindObject("p44")
    expression132.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId301, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId302 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId302, None)
    
    markId303 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId301, "Edit Driving Value")
    
    sketchRapidDimensionBuilder29.Destroy()
    
    theSession.UndoToMark(markId303, None)
    
    theSession.DeleteUndoMark(markId303, None)
    
    sketchRapidDimensionBuilder29.Destroy()
    
    markId304 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchLinearDimensionBuilder17 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension5)
    
    sketchLinearDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId304, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1163 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1164 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder17.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits1165 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1166 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1167 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1168 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1169 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1170 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1171 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1172 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1173 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1174 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1175 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1176 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1177 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1178 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1179 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1180 = sketchLinearDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId305 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId305, None)
    
    markId306 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder17.Driving.ExpressionValue.SetFormula("4")
    
    sketchLinearDimensionBuilder17.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    nXObject55 = sketchLinearDimensionBuilder17.Commit()
    
    point1_97 = NXOpen.Point3d(19.366518589842322, 7.0, 9.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line20, NXOpen.View.Null, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(16.614628393487674, 7.0, 6.0970531614913952)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line20, NXOpen.View.Null, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    sketchLinearDimensionBuilder17.Driving.ExpressionValue.SetFormula("4")
    
    theSession.SetUndoMarkName(markId306, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId306, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId304, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId307 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    scaleAboutPoint165 = NXOpen.Point3d(-2.7569110970061899, 1.4189983587531707, 0.0)
    viewCenter165 = NXOpen.Point3d(2.7569110970061899, -1.4189983587532, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-3.446138871257741, 1.7484086920351598, 0.0)
    viewCenter166 = NXOpen.Point3d(3.4461388712577321, -1.74840869203519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-4.3393476595800653, 2.0904886535203064, 0.0)
    viewCenter167 = NXOpen.Point3d(4.3393476595800431, -2.0904886535203335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-5.4241845744750758, 2.6131108169003805, 0.0)
    viewCenter168 = NXOpen.Point3d(5.424184574475059, -2.6131108169004107, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint168, viewCenter168)
    
    markId308 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject56 = sketchLinearDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId308, None)
    
    theSession.SetUndoMarkName(markId304, "Linear Dimension")
    
    expression133 = sketchLinearDimensionBuilder17.Driving.ExpressionValue
    sketchLinearDimensionBuilder17.Destroy()
    
    theSession.DeleteUndoMark(markId307, None)
    
    theSession.SetUndoMarkVisibility(markId304, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId306, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId309 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section6
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression134 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("1")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("1")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("1")
    
    smartVolumeProfileBuilder6 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId309, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId310 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves8 = [NXOpen.ICurve.Null] * 11 
    curves8[0] = line20
    curves8[1] = line19
    curves8[2] = line21
    curves8[3] = line16
    curves8[4] = line25
    curves8[5] = line24
    curves8[6] = line23
    curves8[7] = line18
    curves8[8] = line22
    curves8[9] = line17
    curves8[10] = line15
    seedPoint8 = NXOpen.Point3d(13.140570803334541, 7.0, 10.333333333333332)
    regionBoundaryRule8 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves8, seedPoint8, 0.01)
    
    section6.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule8
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section6.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId310, None)
    
    markId311 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId312 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId312, None)
    
    direction13 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction13
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies32)
    
    expression135 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId311, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies33)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 1.0
    rotMatrix24.Xy = 0.0
    rotMatrix24.Xz = 0.0
    rotMatrix24.Yx = 0.0
    rotMatrix24.Yy = 0.99265523017222912
    rotMatrix24.Yz = -0.12097765914299731
    rotMatrix24.Zx = 0.0
    rotMatrix24.Zy = 0.12097765914299731
    rotMatrix24.Zz = 0.99265523017222912
    translation24 = NXOpen.Point3d(-26.425085202524155, 0.74507851743828724, -10.637527406159986)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 5.3461184690861447)
    
    markId313 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId313, None)
    
    markId314 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    markId315 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature17 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId314, None)
    
    theSession.SetUndoMarkName(markId309, "Extrude")
    
    expression136 = extrudeBuilder8.Limits.StartExtend.Value
    expression137 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression134)
    
    workPart.Expressions.Delete(expression135)
    
    scaleAboutPoint169 = NXOpen.Point3d(-16.678377751807467, 2.227083082585553, 0.0)
    viewCenter169 = NXOpen.Point3d(16.678377751807449, -2.2270830825855823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-13.34270220144597, 1.7816664660684427, 0.0)
    viewCenter170 = NXOpen.Point3d(13.342702201445963, -1.7816664660684629, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-10.674161761156775, 1.4253331728547514, 0.0)
    viewCenter171 = NXOpen.Point3d(10.674161761156769, -1.4253331728547729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-13.34270220144597, 1.7816664660684429, 0.0)
    viewCenter172 = NXOpen.Point3d(13.34270220144597, -1.7816664660684631, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-16.678377751807457, 2.2270830825855574, 0.0)
    viewCenter173 = NXOpen.Point3d(16.678377751807457, -2.2270830825855787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.98263531091424117
    rotMatrix25.Xy = -0.18505572529235714
    rotMatrix25.Xz = -0.013499047410606129
    rotMatrix25.Yx = 0.094517404801437513
    rotMatrix25.Yy = 0.56183142601689562
    rotMatrix25.Yz = -0.82183447781741592
    rotMatrix25.Zx = 0.15966936441933788
    rotMatrix25.Zy = 0.80628768270161677
    rotMatrix25.Zz = 0.56956638488378586
    translation25 = NXOpen.Point3d(-29.516898211296663, 8.7571884405074876, -11.133419074939438)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 4.2768947752689161)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()